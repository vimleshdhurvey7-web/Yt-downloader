package com.example.ytdownloader

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The action area under the format list.
 *
 * Each [DownloadState] gets its own card so the panel never "changes size
 * abruptly" mid-job: Idle is a single primary button, Running swaps that button
 * for a live progress readout, Done and Failed show a result summary with two
 * recovery actions.
 */
@Composable
fun DownloadPanel(
    state: DownloadState,
    onStart: () -> Unit,
    onCancel: () -> Unit,
    onDismiss: () -> Unit,
    startEnabled: Boolean
) {
    when (state) {
        is DownloadState.Idle -> IdlePanel(startEnabled, onStart)
        is DownloadState.Running -> RunningPanel(state, onCancel)
        is DownloadState.Done -> DonePanel(state, onStart, onDismiss)
        is DownloadState.Failed -> FailedPanel(state.message, onStart, onDismiss)
    }
}

// ---------------------------------------------------------------------------
// Idle
// ---------------------------------------------------------------------------

@Composable
private fun IdlePanel(enabled: Boolean, onStart: () -> Unit) {
    ShimmerButton(
        text = "Download",
        enabled = enabled,
        onClick = onStart,
        modifier = Modifier.fillMaxWidth()
    )
}

/**
 * Primary action with a highlight that sweeps across the face every few seconds.
 *
 * The sweep is drawn *above* the button content as a translucent gradient, so it
 * cannot wash out the label the way an opaque overlay would. When [enabled] is
 * false the sweep stops dead rather than continuing over a disabled control.
 */
@Composable
fun ShimmerButton(
    text: String,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Int = 54,
    loading: Boolean = false
) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val sweep by transition.animateFloat(
        initialValue = -0.4f,
        targetValue = 1.4f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep"
    )

    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(height.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent,
            disabledContainerColor = Color.Transparent
        ),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        if (enabled) listOf(BrandRed, Color(0xFFE0213C), BrandRedDeep)
                        else listOf(CardSurfaceHigh, CardSurfaceHigh)
                    )
                )
                .drawBehind {
                    if (!enabled) return@drawBehind
                    val bandWidth = size.width * 0.45f
                    val x = sweep * size.width - bandWidth / 2
                    drawRect(
                        brush = Brush.horizontalGradient(
                            listOf(
                                Color.Transparent,
                                Color.White.copy(alpha = 0.22f),
                                Color.Transparent
                            ),
                            startX = x,
                            endX = x + bandWidth
                        ),
                        topLeft = Offset(0f, 0f),
                        size = Size(size.width, size.height)
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (loading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    text = text,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = if (enabled) Color.White else InkTertiary,
                    letterSpacing = 0.3.sp
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Running
// ---------------------------------------------------------------------------

@Composable
private fun RunningPanel(state: DownloadState.Running, onCancel: () -> Unit) {
    val percent = state.percent.coerceIn(0f, 1f)
    val animated by animateFloatAsState(
        targetValue = percent,
        animationSpec = tween(600, easing = EaseOutSoft),
        label = "downloadProgress"
    )

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        glow = BrandRed
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PulsingDot()
                Spacer(Modifier.width(9.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = state.stage,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = InkPrimary,
                        maxLines = 1
                    )
                    Text(
                        text = "Keep the app open while it finishes",
                        style = MaterialTheme.typography.labelSmall,
                        color = InkTertiary
                    )
                }
                Text(
                    text = "${(percent * 100).toInt()}%",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = BrandRed
                )
            }

            Spacer(Modifier.height(14.dp))
            GradientProgressBar(animated, indeterminate = false)
            Spacer(Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = buildString {
                        val done = formatBytes(state.downloadedBytes)
                        val total = formatBytes(state.totalBytes)
                        if (done.isNotEmpty()) append(done)
                        if (total.isNotEmpty()) append(" / ").append(total)
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = InkSecondary,
                    modifier = Modifier.weight(1f)
                )
                if (state.speedBytesPerSec > 0) {
                    SpeedPill(formatBytes(state.speedBytesPerSec) + "/s")
                }
            }

            Spacer(Modifier.height(10.dp))
            androidx.compose.material3.TextButton(
                onClick = onCancel,
                modifier = Modifier.align(Alignment.End)
            ) {
                Text(
                    "Cancel",
                    style = MaterialTheme.typography.labelLarge,
                    color = InkTertiary
                )
            }
        }
    }
}

/**
 * A 10 dp track with a gradient fill and a soft bloom on its leading edge.
 *
 * Deliberately hand-drawn rather than a `LinearProgressIndicator`: the stock
 * indicator cannot show a gradient or a glow, and both are what make the bar look
 * like a product instead of a debug readout. The bloom is a radial gradient
 * circle at the fill's end, which is far cheaper than a real blur.
 */
@Composable
private fun GradientProgressBar(progress: Float, indeterminate: Boolean) {
    val transition = rememberInfiniteTransition(label = "barShimmer")
    val shimmer by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "barShimmerValue"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(10.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.07f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .drawBehind {
                    val w = size.width * progress.coerceIn(0f, 1f)
                    if (w <= 0f) return@drawBehind
                    val h = size.height

                    // Bloom behind the leading edge.
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(BrandRed.copy(alpha = 0.55f), Color.Transparent),
                            center = Offset(w, h / 2f),
                            radius = h * 2.2f
                        ),
                        radius = h * 2.2f,
                        center = Offset(w, h / 2f)
                    )
                    // Fill.
                    drawRect(
                        brush = Brush.horizontalGradient(
                            listOf(BrandRedDeep, BrandRed, BrandAmber)
                        ),
                        size = Size(w, h)
                    )
                    // Travelling highlight inside the fill.
                    val band = w * 0.28f
                    val x = progress * shimmer * size.width
                    drawRect(
                        brush = Brush.horizontalGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.30f), Color.Transparent),
                            startX = x - band,
                            endX = x + band
                        ),
                        size = Size(w, h)
                    )
                }
        )
    }
}

@Composable
private fun PulsingDot() {
    val transition = rememberInfiniteTransition(label = "pulse")
    val scale by transition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = EaseOutSoft),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )
    Box(
        modifier = Modifier
            .size(9.dp)
            .clip(CircleShape)
            .background(BrandRed.copy(alpha = 0.35f + 0.65f * scale))
    )
}

@Composable
private fun SpeedPill(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SuccessGreen.copy(alpha = 0.12f))
            .border(1.dp, SuccessGreen.copy(alpha = 0.22f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = SuccessGreen
        )
    }
}

// ---------------------------------------------------------------------------
// Done
// ---------------------------------------------------------------------------

@Composable
private fun DonePanel(state: DownloadState.Done, onStart: () -> Unit, onDismiss: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth(), glow = SuccessGreen) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(SuccessGreen.copy(alpha = 0.14f))
                        .border(1.dp, SuccessGreen.copy(alpha = 0.32f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.Check,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Saved",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = InkPrimary
                    )
                    Text(
                        text = state.location,
                        style = MaterialTheme.typography.labelMedium,
                        color = SuccessGreen
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.30f))
                    .border(1.dp, Hairline.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                Column {
                    Text(
                        text = state.fileName,
                        style = MaterialTheme.typography.bodySmall,
                        color = InkPrimary,
                        maxLines = 2
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        text = "Open your file manager and look in the folder above.",
                        style = MaterialTheme.typography.labelSmall,
                        color = InkTertiary
                    )
                }
            }

            if (state.audioFromProgressive) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "YouTube blocked the audio-only track, so the audio was taken " +
                        "from the 360p combined stream instead.",
                    style = MaterialTheme.typography.labelSmall,
                    color = WarnAmber.copy(alpha = 0.9f)
                )
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SecondaryButton("Done", onDismiss, Modifier.weight(1f))
                ShimmerButton(
                    text = "Download again",
                    enabled = true,
                    onClick = onStart,
                    modifier = Modifier.weight(1f),
                    height = 46
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Failed
// ---------------------------------------------------------------------------

@Composable
private fun FailedPanel(message: String, onStart: () -> Unit, onDismiss: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth(), glow = ErrorRed) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(ErrorRed.copy(alpha = 0.14f))
                        .border(1.dp, ErrorRed.copy(alpha = 0.30f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.Close,
                        contentDescription = null,
                        tint = ErrorRed,
                        modifier = Modifier.size(19.dp)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Text(
                    "Download failed",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = InkPrimary
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = InkSecondary
            )
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SecondaryButton("Dismiss", onDismiss, Modifier.weight(1f))
                ShimmerButton(
                    text = "Try again",
                    enabled = true,
                    onClick = onStart,
                    modifier = Modifier.weight(1f),
                    height = 46
                )
            }
        }
    }
}

@Composable
private fun SecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(46.dp),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Hairline),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = Color.White.copy(alpha = 0.04f),
            contentColor = InkPrimary
        )
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Medium
        )
    }
}
