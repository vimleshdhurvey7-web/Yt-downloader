package com.example.ytdownloader

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Records the stack trace of an uncaught exception so a crash can be read
 * instead of guessed about.
 *
 * The report goes to Downloads/TubeGrab-crash.txt (reachable from any file
 * manager) and to the app's own external folder (one file per crash plus
 * last-crash.txt). A one line summary is kept in preferences so the next
 * launch can say which code path died even if nobody opens the file.
 */
object CrashLog {

    private const val PREFS = "crash_log"
    private const val KEY_SUMMARY = "last_summary"
    private const val KEY_TIME = "last_time"

    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        if (previous is Handler) return
        Thread.setDefaultUncaughtExceptionHandler(Handler(app, previous))
    }

    /** One line summary of the last crash, or null when the app exited cleanly. */
    fun lastSummary(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_SUMMARY, null)

    fun lastTime(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TIME, null)

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove(KEY_SUMMARY)
            .remove(KEY_TIME)
            .apply()
    }

    private class Handler(
        private val context: Context,
        private val previous: Thread.UncaughtExceptionHandler?
    ) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(thread: Thread, error: Throwable) {
            try {
                record(context, thread, error)
            } catch (_: Throwable) {
                // A crash reporter must never crash.
            }
            if (previous != null) previous.uncaughtException(thread, error)
            else android.os.Process.killProcess(android.os.Process.myPid())
        }
    }

    private fun record(context: Context, thread: Thread, error: Throwable) {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val report = StringWriter().also { buffer ->
            PrintWriter(buffer).use { out ->
                out.println("TubeGrab crash report")
                out.println("time    : $stamp")
                out.println("device  : " + Build.MANUFACTURER + " " + Build.MODEL)
                out.println("android : " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")")
                out.println("thread  : " + thread.name)
                out.println()
                error.printStackTrace(out)
            }
        }.toString()

        val summary = summarise(error)

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_SUMMARY, summary)
            .putString(KEY_TIME, stamp)
            .apply()

        try {
            val dir = context.getExternalFilesDir(null) ?: context.filesDir
            File(dir, "crash-" + System.currentTimeMillis() + ".txt").writeText(report)
            File(dir, "last-crash.txt").writeText(report)
        } catch (_: Throwable) {
        }

        try {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "TubeGrab-crash.txt")
                put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { it.write(report.toByteArray()) }
                resolver.update(
                    uri,
                    ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) },
                    null,
                    null
                )
            }
        } catch (_: Throwable) {
        }
    }

    /** "NullPointerException: foo @ Downloader.kt:212" beats a wall of text. */
    private fun summarise(error: Throwable): String {
        val head = error.javaClass.simpleName +
            (error.message?.let { ": " + it.replace('\n', ' ').take(160) } ?: "")
        val top = error.stackTrace.firstOrNull { !it.className.startsWith("android.") }
        return if (top == null || top.fileName == null) head
        else head + "  @ " + top.fileName + ":" + top.lineNumber
    }
}
