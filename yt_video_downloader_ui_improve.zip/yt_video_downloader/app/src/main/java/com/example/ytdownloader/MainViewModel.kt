package com.example.ytdownloader

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class DownloadMode { Video, Audio }

data class UiState(
    val urlText: String = "",
    val loading: Boolean = false,
    val info: VideoInfo? = null,
    val error: String? = null,
    val mode: DownloadMode = DownloadMode.Video,
    val selectedVideoItag: Int? = null,
    val selectedAudioItag: Int? = null,
    val progressiveOnly: Boolean = false,
    val download: DownloadState = DownloadState.Idle
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val downloader = Downloader(app)

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var fetchJob: Job? = null
    private var downloadJob: Job? = null

    fun onUrlChange(value: String) {
        _state.value = _state.value.copy(urlText = value, error = null)
    }

    fun dismissError() {
        _state.value = _state.value.copy(error = null)
    }

    /**
     * Surfaces the stack trace of the previous run's crash, if there was one,
     * instead of leaving the user with a silent restart. The full report is in
     * Downloads/TubeGrab-crash.txt.
     */
    fun reportPreviousCrash(summary: String?, time: String?) {
        if (summary.isNullOrBlank()) return
        val when_ = time?.let { " ($it)" } ?: ""
        _state.value = _state.value.copy(
            error = "TubeGrab closed unexpectedly last time$when_:\n$summary\n\n" +
                "A full report was saved to Downloads/TubeGrab-crash.txt."
        )
    }

    fun pasteAndFetch(text: String) {
        _state.value = _state.value.copy(urlText = text)
        fetch()
    }

    fun fetch() {
        val current = _state.value
        val id = InnerTube.extractVideoId(current.urlText)
        if (id == null) {
            _state.value = current.copy(error = "Paste a YouTube link or an 11-character video ID.")
            return
        }
        fetchJob?.cancel()
        _state.value = current.copy(
            loading = true,
            error = null,
            info = null,
            download = DownloadState.Idle,
            selectedVideoItag = null,
            selectedAudioItag = null
        )
        fetchJob = viewModelScope.launch {
            when (val result = InnerTube.fetchVideoInfo(id)) {
                is FetchResult.Success -> {
                    val info = result.info
                    _state.value = _state.value.copy(
                        loading = false,
                        info = info,
                        selectedVideoItag = info.videoFormats.firstOrNull()?.itag
                            ?: info.progressiveFormats.firstOrNull()?.itag,
                        selectedAudioItag = info.audioFormats.firstOrNull()?.itag
                    )
                }
                is FetchResult.Failure ->
                    _state.value = _state.value.copy(loading = false, error = result.message)
            }
        }
    }

    fun setMode(mode: DownloadMode) {
        _state.value = _state.value.copy(mode = mode)
    }

    fun selectVideo(itag: Int) {
        _state.value = _state.value.copy(selectedVideoItag = itag)
    }

    fun selectAudio(itag: Int) {
        _state.value = _state.value.copy(selectedAudioItag = itag)
    }

    fun toggleProgressiveOnly() {
        val next = !_state.value.progressiveOnly
        val info = _state.value.info
        val selected = if (next) {
            info?.progressiveFormats?.firstOrNull()?.itag ?: _state.value.selectedVideoItag
        } else {
            info?.videoFormats?.firstOrNull()?.itag ?: _state.value.selectedVideoItag
        }
        _state.value = _state.value.copy(progressiveOnly = next, selectedVideoItag = selected)
    }

    fun cancelDownload() {
        downloadJob?.cancel()
        downloadJob = null
        _state.value = _state.value.copy(download = DownloadState.Idle)
    }

    fun resetDownload() {
        if (_state.value.download is DownloadState.Running) return
        _state.value = _state.value.copy(download = DownloadState.Idle)
    }

    fun startDownload() {
        val current = _state.value
        val info = current.info ?: return
        if (current.download is DownloadState.Running) return

        val video: MediaFormat?
        val audio: MediaFormat?
        if (current.mode == DownloadMode.Audio) {
            video = null
            audio = info.audioFormats.firstOrNull { it.itag == current.selectedAudioItag }
                ?: info.audioFormats.firstOrNull()
            if (audio == null) {
                _state.value = current.copy(
                    download = DownloadState.Failed("This video has no audio-only stream available.")
                )
                return
            }
        } else if (current.progressiveOnly) {
            video = info.progressiveFormats.firstOrNull { it.itag == current.selectedVideoItag }
                ?: info.progressiveFormats.firstOrNull()
            audio = null
            if (video == null) {
                _state.value = current.copy(
                    download = DownloadState.Failed("No combined stream is available. Turn off single file mode.")
                )
                return
            }
        } else {
            video = info.videoFormats.firstOrNull { it.itag == current.selectedVideoItag }
                ?: info.videoFormats.firstOrNull()
            audio = info.audioFormats.firstOrNull { it.itag == current.selectedAudioItag }
                ?: info.audioFormats.firstOrNull()
            if (video == null) {
                _state.value = current.copy(
                    download = DownloadState.Failed("No video stream is available for this video.")
                )
                return
            }
        }

        val merge = video != null && audio != null
        _state.value = current.copy(download = DownloadState.Running("Preparing", 0f, 0, 0, 0))
        downloadJob = viewModelScope.launch {
            // download() turns its own failures into DownloadState.Failed, but a
            // throwing OutOfMemoryError or a MediaCodec death would escape the
            // scope and take the whole app down mid-download.
            val result = try {
                downloader.download(info, video, audio, merge) { stage, pct, done, total, speed ->
                    _state.value = _state.value.copy(
                        download = DownloadState.Running(stage, pct, done, total, speed)
                    )
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                DownloadState.Failed(e.message ?: "The download failed unexpectedly.")
            }
            _state.value = _state.value.copy(download = result)
        }
    }

    override fun onCleared() {
        downloadJob?.cancel()
        fetchJob?.cancel()
        super.onCleared()
    }
}
