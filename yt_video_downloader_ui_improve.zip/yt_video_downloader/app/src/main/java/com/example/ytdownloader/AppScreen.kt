package com.example.ytdownloader

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun AppScreen(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current

    Box(modifier = Modifier.fillMaxSize().background(Canvas)) {
        // Ambient light behind everything; it must never eat a touch event, so it
        // is drawn as a plain Canvas child with no gesture modifiers.
        AuroraBackdrop()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            TopBar()

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { SearchCard(state, viewModel) { clipboard.getText()?.text.orEmpty() } }

                state.error?.let { message ->
                    item { ErrorCard(message) { viewModel.dismissError() } }
                }

                val info = state.info
                if (info != null) {
                    item {
                        BlurFade(delayMillis = 40) { VideoHeaderCard(info) }
                    }
                    item {
                        BlurFade(delayMillis = 90) {
                            ModeSelector(state.mode, viewModel::setMode)
                        }
                    }

                    if (state.mode == DownloadMode.Video) {
                        item {
                            SectionLabel(
                                if (state.progressiveOnly) "Combined quality" else "Video quality"
                            )
                        }
                        if (state.progressiveOnly) {
                            if (info.progressiveFormats.isEmpty()) {
                                item { Hint("No pre-merged stream for this video - turn the switch off.") }
                            } else {
                                items(
                                    info.progressiveFormats,
                                    key = { uniqueKey("p", info.progressiveFormats.indexOf(it)) }
                                ) { f ->
                                    FormatRow(f, "with audio", state.selectedVideoItag) {
                                        viewModel.selectVideo(it)
                                    }
                                }
                            }
                        } else {
                            items(
                                info.videoFormats,
                                key = { uniqueKey("v", info.videoFormats.indexOf(it)) }
                            ) { f ->
                                FormatRow(f, formatBytes(f.sizeBytes), state.selectedVideoItag) {
                                    viewModel.selectVideo(it)
                                }
                            }
                        }

                        item { ProgressiveSwitchRow(state, info, viewModel) }

                        if (!state.progressiveOnly && info.audioFormats.isNotEmpty()) {
                            item { SectionLabel("Audio track") }
                            items(
                                info.audioFormats,
                                key = { uniqueKey("a", info.audioFormats.indexOf(it)) }
                            ) { f ->
                                FormatRow(f, formatBytes(f.sizeBytes), state.selectedAudioItag) {
                                    viewModel.selectAudio(it)
                                }
                            }
                        }
                    } else {
                        item { SectionLabel("Audio quality") }
                        if (info.audioFormats.isEmpty()) {
                            item { Hint("This video has no audio-only stream.") }
                        } else {
                            items(
                                info.audioFormats,
                                key = { uniqueKey("ao", info.audioFormats.indexOf(it)) }
                            ) { f ->
                                FormatRow(f, formatBytes(f.sizeBytes), state.selectedAudioItag) {
                                    viewModel.selectAudio(it)
                                }
                            }
                        }
                    }

                    item {
                        Spacer(Modifier.height(6.dp))
                        SelectionSummary(state, info)
                        Spacer(Modifier.height(10.dp))
                        DownloadPanel(
                            state = state.download,
                            onStart = viewModel::startDownload,
                            onCancel = viewModel::cancelDownload,
                            onDismiss = viewModel::resetDownload,
                            startEnabled = true
                        )
                    }
                } else if (!state.loading) {
                    item { EmptyState() }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Selected-quality summary
// ---------------------------------------------------------------------------

/**
 * A one-line recap of what the Download button will actually do, with the combined
 * size when it is known.
 *
 * Without this the download panel is ambiguous: the format list can be a dozen
 * rows long, two of them are selected (video + audio), and after picking an audio
 * track you have to scroll up to remember which video you chose. The chip row is
 * the answer to "what am I about to download?".
 */
@Composable
private fun SelectionSummary(state: UiState, info: VideoInfo) {
    val rows = selectedRows(state, info)
    if (rows.isEmpty()) return

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        contentPadding = 13.dp
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Your selection",
                    style = MaterialTheme.typography.labelMedium,
                    color = InkTertiary,
                    letterSpacing = 0.8.sp,
                    modifier = Modifier.weight(1f)
                )
                val total = rows.sumOf { it.second.sizeBytes }
                if (total > 0) {
                    Text(
                        text = formatBytes(total),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = InkSecondary
                    )
                }
            }
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                rows.forEach { (kind, format) ->
                    SummaryChip(kind, format.label)
                }
            }
        }
    }
}

/**
 * The formats the current mode will actually use, mirroring the fallback rules in
 * `MainViewModel.startDownload` (`?: firstOrNull()`). Kept as a plain function so
 * the summary can never disagree with what the Download button will do.
 */
private fun selectedRows(
    state: UiState,
    info: VideoInfo
): List<Pair<String, MediaFormat>> {
    val out = mutableListOf<Pair<String, MediaFormat>>()
    if (state.mode == DownloadMode.Audio) {
        val audio = info.audioFormats.firstOrNull { it.itag == state.selectedAudioItag }
            ?: info.audioFormats.firstOrNull()
        if (audio != null) out += "Audio" to audio
        return out
    }
    if (state.progressiveOnly) {
        val prog = info.progressiveFormats.firstOrNull { it.itag == state.selectedVideoItag }
            ?: info.progressiveFormats.firstOrNull()
        if (prog != null) out += "Video" to prog
        return out
    }
    (info.videoFormats.firstOrNull { it.itag == state.selectedVideoItag }
        ?: info.videoFormats.firstOrNull())?.let { out += "Video" to it }
    (info.audioFormats.firstOrNull { it.itag == state.selectedAudioItag }
        ?: info.audioFormats.firstOrNull())?.let { out += "Audio" to it }
    return out
}

@Composable
private fun SummaryChip(kind: String, value: String) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(9.dp))
            .background(BrandRed.copy(alpha = 0.10f))
            .border(1.dp, BrandRed.copy(alpha = 0.22f), RoundedCornerShape(9.dp))
            .padding(horizontal = 9.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = kind,
            style = MaterialTheme.typography.labelSmall,
            color = BrandRed.copy(alpha = 0.85f)
        )
        Spacer(Modifier.width(5.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = InkPrimary
        )
    }
}

/**
 * A list key that can never repeat.
 *
 * The format list is keyed on position rather than on itag: YouTube can hand
 * out the same itag twice (an auto-dubbed video splits one track across a kbps
 * boundary), and a repeated LazyColumn key throws "Key was already used" while
 * composing - a hard crash with no recovery. Position is unique by definition,
 * and the list is rebuilt wholesale on every fetch, so nothing is lost.
 */
private fun uniqueKey(prefix: String, index: Int): String = prefix + index

@Composable
private fun FormatRow(
    f: MediaFormat,
    subtitle: String,
    selectedItag: Int?,
    onSelect: (Int) -> Unit
) {
    FormatCard(
        title = f.label + if (f.fps > 30) " · " + f.fps + "fps" else "",
        subtitle = subtitle,
        badge = f.badge,
        selected = selectedItag == f.itag,
        onClick = { onSelect(f.itag) }
    )
}

// ---------------------------------------------------------------------------
// Top bar
// ---------------------------------------------------------------------------

@Composable
private fun TopBar() {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand mark: a gradient tile with the play glyph, sized as a real
            // touch target anchor for the header rather than a decorative dot.
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(
                        Brush.linearGradient(listOf(BrandRed, Color(0xFFE01B3C), BrandRedDeep))
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(13.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "▶",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.width(11.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "TubeGrab",
                    style = MaterialTheme.typography.titleLarge,
                    color = InkPrimary
                )
                Text(
                    text = "YouTube video & audio downloader",
                    style = MaterialTheme.typography.labelSmall,
                    color = InkTertiary,
                    letterSpacing = 0.1.sp
                )
            }
        }
        FadingRule(modifier = Modifier.padding(horizontal = 16.dp))
    }
}

// ---------------------------------------------------------------------------
// Search
// ---------------------------------------------------------------------------

@Composable
private fun SearchCard(
    state: UiState,
    viewModel: MainViewModel,
    readClipboard: () -> String
) {
    val focusManager = LocalFocusManager.current
    var focused by remember { mutableStateOf(false) }
    val borderColor = if (focused) BrandRed.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.07f)

    GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 14.dp) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black.copy(alpha = 0.34f))
                    .border(1.dp, borderColor, RoundedCornerShape(14.dp))
                    .padding(horizontal = 13.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Filled.Search,
                    contentDescription = null,
                    tint = if (focused) BrandRed else InkTertiary,
                    modifier = Modifier.size(17.dp)
                )
                Spacer(Modifier.width(10.dp))
                Box(modifier = Modifier.weight(1f)) {
                    if (state.urlText.isEmpty()) {
                        Text(
                            text = "Paste a YouTube link or ID",
                            style = MaterialTheme.typography.bodyLarge,
                            color = InkTertiary
                        )
                    }
                    // BasicTextField instead of OutlinedTextField: it carries no
                    // label/indicator machinery, so the row height is exact and
                    // the whole field is one custom surface.
                    BasicTextField(
                        value = state.urlText,
                        onValueChange = viewModel::onUrlChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .onFocusChanged { focused = it.isFocused },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = InkPrimary,
                            fontWeight = FontWeight.Medium
                        ),
                        cursorBrush = SolidColor(BrandRed),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Uri,
                            imeAction = ImeAction.Go
                        ),
                        keyboardActions = KeyboardActions(
                            onGo = {
                                focusManager.clearFocus()
                                if (state.urlText.isNotBlank()) viewModel.fetch()
                            }
                        )
                    )
                }
                if (state.urlText.isNotEmpty()) {
                    Spacer(Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.08f))
                            .clickable { viewModel.onUrlChange("") },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Filled.Clear,
                            contentDescription = "Clear link",
                            tint = InkSecondary,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton(
                    text = "Paste",
                    enabled = !state.loading,
                    modifier = Modifier.width(96.dp),
                    onClick = {
                        val text = readClipboard()
                        if (text.isNotBlank()) viewModel.pasteAndFetch(text)
                    }
                )
                ShimmerButton(
                    text = if (state.loading) "Fetching…" else "Get video",
                    enabled = !state.loading && state.urlText.isNotBlank(),
                    onClick = {
                        focusManager.clearFocus()
                        viewModel.fetch()
                    },
                    modifier = Modifier.weight(1f),
                    height = 50,
                    loading = state.loading
                )
            }
        }
    }
}

/**
 * Quiet secondary action: a ghost outline that only warms up when tapped. Used
 * for "Paste" so it never competes with the primary fetch button.
 */
@Composable
fun GhostButton(
    text: String,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    height: Int = 50,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(height.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.04f))
            .border(1.dp, Hairline, RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Medium,
            color = if (enabled) InkSecondary else InkTertiary.copy(alpha = 0.45f)
        )
    }
}

// ---------------------------------------------------------------------------
// Single-file switch
// ---------------------------------------------------------------------------

@Composable
private fun ProgressiveSwitchRow(state: UiState, info: VideoInfo, viewModel: MainViewModel) {
    val on = state.progressiveOnly
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        contentPadding = 14.dp,
        glow = if (on) BrandRed else null
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Single file (no merging)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Medium,
                    color = InkPrimary
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "Lower quality, ready instantly",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkTertiary
                )
            }
            Spacer(Modifier.width(10.dp))
            Switch(
                checked = on,
                onCheckedChange = { viewModel.toggleProgressiveOnly() },
                enabled = info.progressiveFormats.isNotEmpty(),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = BrandRed,
                    checkedBorderColor = BrandRed,
                    uncheckedThumbColor = InkTertiary,
                    uncheckedTrackColor = Color.White.copy(alpha = 0.08f),
                    uncheckedBorderColor = Hairline
                )
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Error / hint / empty
// ---------------------------------------------------------------------------

@Composable
private fun ErrorCard(message: String, onDismiss: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ErrorRed.copy(alpha = 0.10f))
            .border(1.dp, ErrorRed.copy(alpha = 0.30f), RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Box(
                modifier = Modifier
                    .padding(top = 5.dp)
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(ErrorRed)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFFFCDD4),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onDismiss),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Dismiss",
                    tint = Color(0xFFFFCDD4).copy(alpha = 0.85f),
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

@Composable
private fun Hint(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = InkTertiary,
        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
    )
}

@Composable
private fun EmptyState() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 64.dp, start = 12.dp, end = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Layered glyph: a dim plate, a bright inset tile, and the accent ring -
        // three depths from two boxes instead of an illustration asset.
        Box(
            modifier = Modifier
                .size(104.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(
                    Brush.linearGradient(
                        listOf(BrandRed.copy(alpha = 0.13f), BrandViolet.copy(alpha = 0.09f))
                    )
                )
                .border(1.dp, Color.White.copy(alpha = 0.07f), RoundedCornerShape(30.dp)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(RoundedCornerShape(19.dp))
                    .background(
                        Brush.linearGradient(listOf(BrandRed, Color(0xFFE01B3C), BrandRedDeep))
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.20f), RoundedCornerShape(19.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "▶",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(Modifier.height(26.dp))
        Text(
            "Paste a link to start",
            style = MaterialTheme.typography.headlineMedium,
            color = InkPrimary,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(9.dp))
        Text(
            "Any resolution up to 4K, or just the audio.\nFiles are saved to Download/TubeGrab.",
            style = MaterialTheme.typography.bodySmall,
            color = InkTertiary,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(26.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StepPill("1", "Paste")
            StepPill("2", "Pick quality")
            StepPill("3", "Download")
        }
    }
}

@Composable
private fun StepPill(index: String, label: String) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(11.dp))
            .background(Color.White.copy(alpha = 0.04f))
            .border(1.dp, Hairline, RoundedCornerShape(11.dp))
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = index,
            style = MaterialTheme.typography.labelSmall,
            color = BrandRed,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.width(5.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = InkSecondary
        )
    }
}
