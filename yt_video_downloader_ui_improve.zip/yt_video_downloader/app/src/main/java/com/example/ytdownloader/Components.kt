package com.example.ytdownloader

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.util.Locale

// ---------------------------------------------------------------------------
// Video header
// ---------------------------------------------------------------------------

/**
 * Thumbnail card: artwork on a 16:9 plate, a bottom-up scrim so white text stays
 * legible over any frame, the duration as a glass pill, and the metadata on a
 * glass body underneath.
 */
@Composable
fun VideoHeaderCard(info: VideoInfo) {
    GlassCard(modifier = Modifier.fillMaxWidth(), contentPadding = 0.dp) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(196.dp)
                    .background(CanvasRaised)
            ) {
                if (info.thumbnailUrl.isNotEmpty()) {
                    AsyncImage(
                        model = info.thumbnailUrl,
                        contentDescription = "Video thumbnail",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                // Scrim: keeps the pill readable and ties the artwork into the card.
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                0f to Color.Transparent,
                                0.55f to Color.Black.copy(alpha = 0.25f),
                                1f to Color.Black.copy(alpha = 0.72f)
                            )
                        )
                )
                // Live badge, top-left: the "premium" cue of the header.
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.55f))
                        .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(BrandRed)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            "READY",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White.copy(alpha = 0.92f),
                            letterSpacing = 1.sp
                        )
                    }
                }
                // Duration pill, bottom-right.
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.68f))
                        .padding(horizontal = 9.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = info.durationLabel,
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = info.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = InkPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(9.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ChannelChip(info.author)
                    Spacer(Modifier.weight(1f))
                    if (info.viewsLabel.isNotEmpty()) {
                        MetaText(info.viewsLabel)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChannelChip(author: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        // Initial avatar: no extra network request, and it keeps the row aligned
        // even for channels with no picture.
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(listOf(BrandRed.copy(alpha = 0.85f), BrandViolet.copy(alpha = 0.85f)))
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = author.trim().take(1).uppercase().ifEmpty { "?" },
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
        Spacer(Modifier.width(7.dp))
        Text(
            text = author,
            style = MaterialTheme.typography.bodySmall,
            color = InkSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun MetaText(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelMedium,
        color = InkTertiary
    )
}

// ---------------------------------------------------------------------------
// Segmented mode control
// ---------------------------------------------------------------------------

/**
 * Two-up segmented control with a sliding "thumb" behind the active label.
 * The thumb is a plain animated offset rather than an animated background so the
 * motion is one clean slide instead of two fading colours.
 */
@Composable
fun ModeSelector(mode: DownloadMode, onChange: (DownloadMode) -> Unit) {
    val videoSelected = mode == DownloadMode.Video
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black.copy(alpha = 0.28f))
            .border(1.dp, Hairline.copy(alpha = 0.9f), RoundedCornerShape(16.dp))
            .padding(4.dp)
    ) {
        val weight = animateFloatAsState(
            targetValue = if (videoSelected) 0f else 1f,
            animationSpec = tween(320, easing = EaseOutSoft),
            label = "modeThumb"
        )
        BoxWithLayoutFraction(fraction = weight.value) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(BrandRed.copy(alpha = 0.22f), BrandViolet.copy(alpha = 0.18f))
                        )
                    )
                    .border(
                        1.dp,
                        BrandRed.copy(alpha = 0.45f),
                        RoundedCornerShape(12.dp)
                    )
            )
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            ModeTab("Video + audio", videoSelected, Modifier.weight(1f)) {
                onChange(DownloadMode.Video)
            }
            ModeTab("Audio only", !videoSelected, Modifier.weight(1f)) {
                onChange(DownloadMode.Audio)
            }
        }
    }
}

/**
 * Places a full-width child so that it covers the left or right half, animated.
 * Written by hand instead of using BoxWithConstraints + offset so the thumb can
 * be a sibling that slides under the labels.
 */
@Composable
private fun BoxWithLayoutFraction(
    fraction: Float,
    content: @Composable () -> Unit
) {
    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
        val half = maxWidth / 2
        Box(
            modifier = Modifier
                .width(half)
                .height(42.dp)
                .offset(x = half * fraction)
        ) {
            content()
        }
    }
}

@Composable
private fun ModeTab(text: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val color by animateColorAsState(
        targetValue = if (selected) InkPrimary else InkTertiary,
        animationSpec = tween(260),
        label = "tabColor"
    )
    Box(
        modifier = modifier
            .height(42.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = color
        )
    }
}

// ---------------------------------------------------------------------------
// Format row
// ---------------------------------------------------------------------------

/**
 * One selectable stream.
 *
 * Selected state is carried by four cheap cues at once - a red-tinted body, a
 * 1.5 dp accent border, a filled check, and a slightly enlarged size label - so
 * it stays readable on a phone screen in daylight and does not rely on colour
 * alone.
 */
@Composable
fun FormatCard(
    title: String,
    subtitle: String,
    badge: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val body by animateColorAsState(
        targetValue = if (selected) Color(0xFF2A1219) else CardSurface.copy(alpha = 0.72f),
        animationSpec = tween(240),
        label = "formatBody"
    )
    val borderWidth by animateDpAsState(
        targetValue = if (selected) 1.5.dp else 1.dp,
        animationSpec = tween(240),
        label = "formatBorder"
    )
    val borderColor by animateColorAsState(
        targetValue = if (selected) BrandRed.copy(alpha = 0.85f) else Hairline.copy(alpha = 0.75f),
        animationSpec = tween(240),
        label = "formatBorderColor"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(body)
            .then(
                if (selected) {
                    Modifier.drawBehind {
                        drawRect(
                            brush = Brush.horizontalGradient(
                                listOf(BrandRed.copy(alpha = 0.16f), Color.Transparent),
                                endX = size.width * 0.75f
                            )
                        )
                    }
                } else Modifier
            )
            .border(borderWidth, borderColor, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SelectionMark(selected)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                    color = if (selected) InkPrimary else InkPrimary.copy(alpha = 0.92f)
                )
                if (subtitle.isNotEmpty()) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (selected) BrandRed.copy(alpha = 0.95f) else InkTertiary
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            BadgePill(badge, selected)
        }
    }
}

@Composable
private fun SelectionMark(selected: Boolean) {
    val size by animateDpAsState(
        targetValue = if (selected) 22.dp else 20.dp,
        animationSpec = tween(220),
        label = "markSize"
    )
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (selected) BrandRed else Color.Transparent)
            .border(
                width = if (selected) 0.dp else 1.5.dp,
                color = if (selected) Color.Transparent else Color(0xFF4A424F),
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Icon(
                Icons.Filled.Check,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
private fun BadgePill(badge: String, selected: Boolean) {
    if (badge.isEmpty()) return
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(7.dp))
            .background(
                if (selected) Color.Black.copy(alpha = 0.35f)
                else Color.White.copy(alpha = 0.05f)
            )
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = badge,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium,
            color = if (selected) Color.White.copy(alpha = 0.95f) else InkTertiary
        )
    }
}

// ---------------------------------------------------------------------------
// Misc
// ---------------------------------------------------------------------------

/**
 * A section label: small caps, wide tracking, with a short accent tick to its
 * left. The tick is what makes a plain list read as a designed screen.
 */
@Composable
fun SectionLabel(text: String) {
    Row(
        modifier = Modifier.padding(top = 6.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(3.dp)
                .height(14.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Brush.verticalGradient(listOf(BrandRed, BrandRedDeep)))
        )
        Spacer(Modifier.width(9.dp))
        Text(
            text = text.uppercase(),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = InkSecondary,
            letterSpacing = 1.2.sp
        )
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return ""
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1 -> String.format(Locale.US, "%.2f GB", gb)
        mb >= 1 -> String.format(Locale.US, "%.1f MB", mb)
        else -> String.format(Locale.US, "%.0f KB", kb)
    }
}
