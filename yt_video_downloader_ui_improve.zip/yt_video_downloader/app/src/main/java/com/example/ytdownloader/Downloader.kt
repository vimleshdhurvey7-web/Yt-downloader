package com.example.ytdownloader

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat as AndroidMediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer

/**
 * Downloads streams into the cache, losslessly remuxes video + audio with
 * MediaMuxer, then publishes the file through MediaStore into Download/TubeGrab
 * (falling back to Movies/TubeGrab or Music/TubeGrab if Android refuses that
 * folder). No runtime storage permission is required on API 29+.
 */
class Downloader(private val context: Context) {

    private val workDir: File by lazy {
        File(context.cacheDir, "downloads").apply { mkdirs() }
    }

    suspend fun download(
        info: VideoInfo,
        videoFormat: MediaFormat?,
        audioFormat: MediaFormat?,
        mergeAudio: Boolean,
        onProgress: (stage: String, percent: Float, done: Long, total: Long, speed: Long) -> Unit
    ): DownloadState = withContext(Dispatchers.IO) {
        var videoFile: File? = null
        var audioFile: File? = null
        var mergedFile: File? = null
        try {
            if (videoFormat == null && audioFormat == null) {
                return@withContext DownloadState.Failed("Pick a format first.")
            }
            val baseName = sanitize(info.title.ifBlank { info.videoId })
            val audioOnly = videoFormat == null
            cleanStaleCache()

            if (videoFormat != null) {
                val share = if (mergeAudio) 0.75f else 0.97f
                // Cache names include the video id, so a retry can safely resume
                // from a partial file instead of starting the stream over.
                videoFile = File(workDir, "v_${info.videoId}_${videoFormat.itag}.${videoFormat.extension}")
                fetch(
                    videoFormat,
                    videoFile,
                    info.videoId,
                    onProgress = { pct, done, total, speed ->
                        onProgress("Downloading video", pct * share, done, total, speed)
                    },
                    onRecover = { msg, pct, done, total ->
                        onProgress(msg, pct * share, done, total, 0)
                    }
                )
            }

            // Set when YouTube refused the audio-only stream and the audio had
            // to be lifted out of the combined (progressive) stream instead.
            var audioFromProgressive = false

            if (audioFormat != null && (mergeAudio || audioOnly)) {
                val base = if (videoFormat == null) 0f else 0.75f
                val share = if (videoFormat == null) 0.97f else 0.20f
                audioFile = File(workDir, "a_${info.videoId}_${audioFormat.itag}.${audioFormat.extension}")
                try {
                    fetch(
                        audioFormat,
                        audioFile,
                        info.videoId,
                        onProgress = { pct, done, total, speed ->
                            onProgress("Downloading audio", base + pct * share, done, total, speed)
                        },
                        onRecover = { msg, pct, done, total ->
                            onProgress(msg, base + pct * share, done, total, 0)
                        }
                    )
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    // Audio-only streams are the one thing YouTube gates behind
                    // a proof-of-origin token: they serve about a megabyte and
                    // then answer 403 no matter how often the URL is re-minted.
                    // The combined stream of the same video is not gated, so pull
                    // the audio track out of it rather than failing the download.
                    val fallback = info.progressiveFormats.firstOrNull()
                        ?: throw e
                    audioFile.delete()
                    val combined = File(workDir, "a_${info.videoId}_${fallback.itag}.mp4")
                    fetch(
                        fallback,
                        combined,
                        info.videoId,
                        onProgress = { pct, done, total, speed ->
                            onProgress("Downloading audio", base + pct * share, done, total, speed)
                        },
                        onRecover = { msg, pct, done, total ->
                            onProgress(msg, base + pct * share, done, total, 0)
                        }
                    )
                    val extracted = File(workDir, "a_${info.videoId}_extracted.m4a")
                    extractAudio(combined, extracted)
                    deleteQuietly(combined)
                    audioFile = extracted
                    audioFromProgressive = true
                }
            }

            var fileName: String
            var location: String
            var targetUri: Uri?

            if (videoFormat != null && audioFile != null && mergeAudio) {
                onProgress("Merging audio + video", 0.95f, 0, 0, 0)
                mergedFile = File(workDir, "merged_${info.videoId}_${videoFormat.height}p.mp4").also { it.delete() }
                try {
                    remux(videoFile!!, audioFile, mergedFile) { pct ->
                        onProgress("Merging audio + video", 0.95f + pct * 0.05f, 0, 0, 0)
                    }
                    val published = publish(mergedFile, baseName, videoFormat, isAudio = false)
                    fileName = published.name
                    targetUri = published.uri
                    location = published.location
                } catch (e: Exception) {
                    // Never lose the download: keep the tracks as separate files.
                    mergedFile.delete()
                    val savedVideo = publish(videoFile!!, baseName, videoFormat, isAudio = false)
                    val savedAudio = if (audioFormat != null) {
                        publish(audioFile, baseName, audioFormat, isAudio = true)
                    } else {
                        null
                    }
                    fileName = savedVideo.name
                    targetUri = savedVideo.uri
                    location = if (savedAudio != null) {
                        "${savedVideo.location} (audio: ${savedAudio.location})"
                    } else {
                        savedVideo.location
                    }
                }
            } else if (videoFormat != null) {
                val published = publish(videoFile!!, baseName, videoFormat, isAudio = false)
                fileName = published.name
                targetUri = published.uri
                location = published.location
            } else {
                // An extracted track is AAC no matter which itag the user picked,
                // so publish it with the container that is actually on disk.
                val owner = if (audioFromProgressive) {
                    audioFormat!!.copy(extension = "m4a", codec = "mp4a.40.2")
                } else {
                    audioFormat!!
                }
                val published = publish(audioFile!!, baseName, owner, isAudio = true)
                fileName = published.name
                targetUri = published.uri
                location = published.location
            }


            deleteQuietly(videoFile)
            deleteQuietly(audioFile)
            deleteQuietly(mergedFile)
            onProgress("Finishing", 1f, 0, 0, 0)
            DownloadState.Done(fileName, location, targetUri, audioFromProgressive)
        } catch (e: kotlinx.coroutines.CancellationException) {
            deleteQuietly(videoFile)
            deleteQuietly(audioFile)
            deleteQuietly(mergedFile)
            throw e
        } catch (e: Exception) {
            // Partial files are kept on purpose: tapping retry resumes the
            // stream from the last byte instead of downloading it again.
            deleteQuietly(mergedFile)
            DownloadState.Failed(e.message ?: "Download failed.")
        }
    }

    // ---------------------------------------------------------------------

    /**
     * Downloads one stream into [target], resuming from whatever was already
     * written.
     *
     * A phone connection can die in three different ways, and all three used to
     * look like "stuck at 10%":
     *
     *  1. the server answers 403 for an offset (the signed URL no longer matches
     *     this connection),
     *  2. the stream goes completely silent - the socket stays open, not one
     *     byte arrives, and a plain read() blocks until the read timeout,
     *  3. the connection dies mid-chunk.
     *
     * Chunks are therefore clocked from *request start*, not from the last byte,
     * and any chunk that takes too long is abandoned and retried on a fresh
     * connection. Progress is reported while reading, so the bar keeps moving
     * even when a slow 4K chunk takes a while.
     */
    private suspend fun fetch(
        format: MediaFormat,
        target: File,
        videoId: String,
        onProgress: (Float, Long, Long, Long) -> Unit,
        onRecover: (String, Float, Long, Long) -> Unit = { _, _, _, _ -> }
    ) {
        var source = InnerTube.StreamSource(format.url, format.userAgent, "")
        var chunk = DEFAULT_CHUNK
        var total = format.sizeBytes
        var done = if (target.exists()) target.length() else 0L
        if (total > 0 && done >= total) {
            onProgress(1f, done, total, 0)
            return
        }

        var lastError: Exception? = null
        // Consecutive failures since the last byte of real progress.
        var strikes = 0
        // 0 = bounded range chunks (resumable), 1 = one continuous read from
        // byte zero, which is the shape that survives the strictest gating.
        var stage = 0
        var windowBytes = 0L
        var windowStart = System.currentTimeMillis()
        var speed = 0L
        // The client that last produced bytes. Chunks are re-signed with it so
        // the signature never has to be re-derived from scratch.
        var goodClient: String? = null
        // Alternatives kept ready: a client that serves this network fine is
        // not the same one that serves the next phone, and a dead client cannot
        // be repaired by asking it for another URL.
        var pool: List<InnerTube.StreamSource> = emptyList()
        var poolIndex = 0

        /** Next client that can serve this itag, or null when none are left. */
        fun nextSource(): InnerTube.StreamSource? {
            if (pool.isEmpty()) {
                pool = InnerTube.resolveStreams(videoId, format.itag, goodClient)
                poolIndex = 0
            }
            if (poolIndex >= pool.size) return null
            return pool[poolIndex++]
        }

        while (true) {
            if (total > 0 && done >= total) break
            // `done` must always equal what is actually on disk. A buffered
            // writer killed mid-chunk can leave the counter ahead of the file,
            // and asking for a range past the real end then gets a flat 416 or
            // 403 forever - a permanent stall that survives every retry.
            val onDisk = if (target.exists()) target.length() else 0L
            if (onDisk != done) done = onDisk
            if (total > 0 && done >= total) break
            val start = done
            val end = if (total > 0) minOf(start + chunk - 1, total - 1) else -1L
            val range = if (end >= 0) "bytes=$start-$end" else "bytes=$start-"
            try {
                val conn = openConnection(source.url, source.userAgent, range)
                try {
                    val code = conn.responseCode
                    if (code == 416) {
                        // "bytes */(total)" carries the real length, which is
                        // authoritative when it came from a bitrate estimate.
                        parseTotalBytes(conn.getHeaderField("Content-Range"))
                            ?.takeIf { it > 0 }
                            ?.let { total = it }
                    }
                    if (code !in 200..299) throw StreamFailure(code)
                    // A 200 means the server ignored Range and is sending the
                    // whole stream from byte zero. Write it from scratch and
                    // stop chunking afterwards, otherwise the data is appended
                    // twice and the file is corrupt.
                    if (code == 200) {
                        target.delete()
                        done = 0L
                    }
                    // Trust the server's own byte range over the bitrate
                    // estimate parsed from the player response.
                    val serverTotal = parseTotalBytes(conn.getHeaderField("Content-Range"))
                    if (serverTotal != null && serverTotal > 0) {
                        total = serverTotal
                    } else if (total <= 0) {
                        total = done + conn.contentLengthLong.coerceAtLeast(0L)
                    }
                    // The server may clamp a range to the real end of the file,
                    // so trust its Content-Length over the requested window.
                    val bodyLength = conn.contentLengthLong
                    val expected = when {
                        code == 200 || end < 0 || total <= 0 -> Long.MAX_VALUE
                        bodyLength > 0 -> minOf(bodyLength, total - done)
                        else -> total - done
                    }
                    var written = 0L
                    try {
                        conn.inputStream.use { input ->
                            FileOutputStream(target, true).buffered(256 * 1024).use { out ->
                                val buf = ByteArray(128 * 1024)
                                while (written < expected) {
                                    val want = minOf(buf.size.toLong(), expected - written).toInt()
                                    val n = input.read(buf, 0, want)
                                    if (n < 0) break
                                    out.write(buf, 0, n)
                                    written += n
                                    done += n
                                    windowBytes += n
                                    val now = System.currentTimeMillis()
                                    val elapsedNow = now - windowStart
                                    if (elapsedNow >= 400) {
                                        speed = windowBytes * 1000L / elapsedNow.coerceAtLeast(1)
                                        windowBytes = 0L
                                        windowStart = now
                                        val pct = if (total > 0) {
                                            (done.toFloat() / total).coerceIn(0f, 1f)
                                        } else 0f
                                        onProgress(pct, done, total, speed)
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        // Bytes that did arrive are already on disk, so keep
                        // them: the next request resumes from `done` instead of
                        // starting the chunk over.
                        if (written == 0L) throw e
                        lastError = e
                        goodClient = source.clientName
                        strikes = 0
                        if (chunk > MIN_CHUNK) chunk = (chunk / 2).coerceAtLeast(MIN_CHUNK)
                        continue
                    }
                    if (written == 0L) throw IOException("The stream ended unexpectedly.")
                    // Real progress: forgive everything that came before.
                    strikes = 0
                    goodClient = source.clientName
                    if (code == 200) break
                    if (chunk < DEFAULT_CHUNK) chunk = (chunk * 2).coerceAtMost(DEFAULT_CHUNK)
                } finally {
                    conn.disconnect()
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = e
                strikes++
                val code = (e as? StreamFailure)?.code ?: 0
                // Tell the UI what is happening, so a slow recovery never looks
                // like a frozen download.
                if (total > 0) {
                    val pct = (done.toFloat() / total).coerceIn(0f, 1f)
                    onRecover(
                        if (code != 0) "Connection dropped, retrying (HTTP $code)"
                        else "Connection stalled, retrying",
                        pct,
                        done,
                        total
                    )
                }
                // Nothing left to fetch: the file is already complete.
                if (code == 416 && total > 0 && done >= total - 1) break

                // A short chunk keeps the transfer alive when the network drops
                // packets; halving beats failing outright.
                if (strikes in 1..2 && chunk > MIN_CHUNK) {
                    chunk = (chunk / 2).coerceAtLeast(MIN_CHUNK)
                }

                // A dead connection is not a dead client, but on a phone the two
                // are impossible to tell apart: a socket that accepts the request
                // and then never answers (read timeout) is usually a specific
                // googlevideo host being unreachable over this radio, and the
                // same itag from another client resolves to a different host.
                // Rotating after a couple of stalls is what turns "stuck at 10%"
                // into a download that finishes.
                if (code == 0 && strikes >= 2) {
                    val alt = nextSource()
                    if (alt != null) {
                        source = alt
                        poolIndex = pool.indexOf(alt) + 1
                        kotlinx.coroutines.delay(500L)
                        continue
                    }
                }

                if (code == 403 || code == 401 || code == 410) {
                    // YouTube answers 403 for three different reasons and they
                    // need opposite treatment, so each one gets its own
                    // escalation step instead of one blind retry loop.
                    //
                    // 1. An audio-only stream is proof-of-origin gated: it serves
                    //    about a megabyte and then refuses forever, however many
                    //    fresh URLs are asked for. Give up at once and let the
                    //    caller rebuild the audio from the combined stream.
                    if (format.isAudio && !format.isProgressive && strikes >= 2) {
                        throw failedMessage(e)
                    }
                    // 2. Everything else usually means the signed URL no longer
                    //    matches this connection (the phone changed address, the
                    //    signature expired), or the connection ran out of
                    //    allowance and is being throttled. A fresh URL fixes the
                    //    first; patience fixes the second. Re-sign with the
                    //    client that was working, not whichever is first.
                    if (strikes in 1..2) {
                        // Same client, fresh URL: cheap and usually enough when
                        // the signature simply went stale.
                        pool = emptyList()
                        poolIndex = 0
                        source = InnerTube.resolveStream(videoId, format.itag, goodClient) ?: source
                        kotlinx.coroutines.delay(1_500L * strikes)
                        continue
                    }
                    if (strikes in 3..5 && strikes < 5) {
                        // Same offset still refused with a brand new URL: this
                        // client is gated on this network, so move to another.
                        // Byte offset is kept - only the URL changes.
                        val alt = nextSource()
                        if (alt != null) {
                            source = alt
                            kotlinx.coroutines.delay(1_000L)
                            continue
                        }
                        // No other client serves this itag: run the gate
                        // breaker below instead of looping.
                        strikes = 6
                    }
                    // 3. Fresh URLs still refuse this offset, which means the
                    //    stream itself is being gated rather than the signature
                    //    having gone stale. A read that starts at byte zero is
                    //    the one shape the gate usually still allows, so try the
                    //    whole stream in a single request before giving up. This
                    //    costs the bytes already on disk, so it happens once and
                    //    only after the cheap repairs above were exhausted.
                    if (stage == 0) {
                        stage = 1
                        strikes = 0
                        source = InnerTube.resolveStream(videoId, format.itag, goodClient) ?: source
                        // Ask for everything in one request from byte zero.
                        chunk = Long.MAX_VALUE / 4
                        if (done > 0) {
                            target.delete()
                            done = 0L
                        }
                        continue
                    }
                }
                if (strikes >= 6) throw failedMessage(e)
                kotlinx.coroutines.delay(1_000L * strikes)
            }
        }

        if (done < 2048) throw lastError ?: IOException("The download came back empty.")
        // A bitrate estimate can be a little over or under the real stream, and
        // a too-small total makes the loop stop early while a too-large one makes
        // it ask for bytes that do not exist (416 forever, which reads as a
        // permanent stall). The last successful chunk tells the truth, so prefer
        // the file length whenever the server confirmed we are at the end.
        if (total > 0 && done < total) {
            // One last confirmation round: a "bytes */N" answer gives the exact
            // size, and a range that already ends at EOF answers 416.
            try {
                val probe = openConnection(source.url, source.userAgent, "bytes=$done-")
                try {
                    if (probe.responseCode == 416) {
                        parseTotalBytes(probe.getHeaderField("Content-Range"))
                            ?.takeIf { it > 0 }
                            ?.let { total = it }
                    }
                } finally {
                    probe.disconnect()
                }
            } catch (_: Exception) {
            }
            if (done >= total) {
                onProgress(1f, done, total, speed)
                return
            }
        }
        // Never hand a half file to the muxer: it would publish a video that
        // stops in the middle. Keeping it lets a retry resume instead.
        if (total > 0 && done < total) {
            throw IOException(
                "The download stopped at ${done * 100 / total}% (${done / 1048576} of " +
                    "${total / 1048576} MB). Tap retry to resume where it stopped."
            )
        }
        onProgress(1f, done, if (total > 0) total else done, speed)
    }

    /** Turns transport errors into something a user can act on. */
    private fun failedMessage(e: Exception): IOException = when {
        e is StreamFailure && e.code == 403 -> IOException(
            "YouTube cut this download off (HTTP 403). It limits how much one " +
                "connection may pull, so a long or high-quality download can hit " +
                "the cap. Everything downloaded so far is kept - wait a few " +
                "minutes and tap retry to carry on from there. To make it " +
                "finish in one go, pick a lower quality or turn on " +
                "\"Single file (no merging)\"."
        )
        e is StreamFailure -> IOException("YouTube refused this download (HTTP ${e.code}).")
        else -> IOException(e.message ?: "Download failed.")
    }

    private companion object {
        /**
         * Bytes requested per HTTP round trip.
         *
         * 1.5 MB is a hard measured limit, not a guess: googlevideo answers 206
         * for a range up to 1.56 MB and a flat 403 with an empty body for
         * anything bigger. The old 2 MB default was over that line, so the very
         * first request of every adaptive download was refused and the file
         * never moved past the first chunk - which is what "stuck at 10%"
         * looked like.
         */
        const val DEFAULT_CHUNK = 1536L * 1024
        const val MIN_CHUNK = 64L * 1024
    }

    private fun parseTotalBytes(contentRange: String?): Long? {
        if (contentRange.isNullOrEmpty()) return null
        val slash = contentRange.lastIndexOf('/')
        if (slash < 0) return null
        return contentRange.substring(slash + 1).trim().toLongOrNull()
    }

    private class StreamFailure(val code: Int) : IOException("Server returned HTTP $code.")

    private fun openConnection(url: String, userAgent: String, range: String?): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 20_000
        // Every read must produce bytes within this window. googlevideo does
        // sometimes accept a request and then never send anything, and a long
        // timeout turns that into a download that looks frozen at a few percent
        // without ever failing. 20 s is far longer than any healthy chunk needs
        // (measured: a 1.5 MB chunk arrives in 0.3 s, the slowest in 5.4 s).
        conn.readTimeout = 20_000
        conn.instanceFollowRedirects = true
        // A stalled socket must not be recycled into a pool and reused.
        conn.setRequestProperty("Connection", "close")
        conn.setRequestProperty(
            "User-Agent",
            if (userAgent.isNotEmpty()) userAgent else "Mozilla/5.0 (Linux; Android 13)"
        )
        conn.setRequestProperty("Accept", "*/*")
        conn.setRequestProperty("Accept-Encoding", "identity")
        if (range != null) conn.setRequestProperty("Range", range)
        conn.connect()
        return conn
    }

    /**
     * Copies just the audio track out of a combined stream, byte for byte.
     * Used when YouTube refuses the audio-only stream: the combined file is not
     * gated, so its AAC track is the same audio the separate one would carry.
     */
    private fun extractAudio(source: File, out: File) {
        out.delete()
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(source.absolutePath)
            val track = firstTrackOfType(extractor, "audio/")
                ?: throw IOException("The downloaded file has no audio track.")
            val format = extractor.getTrackFormat(track)
            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val outTrack = muxer.addTrack(format)
            muxer.start()
            extractor.selectTrack(track)

            val buffer = ByteBuffer.allocateDirect(1024 * 1024)
            val info = MediaCodec.BufferInfo()
            while (true) {
                buffer.clear()
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                info.offset = 0
                info.size = size
                info.presentationTimeUs = extractor.sampleTime
                info.flags = extractor.sampleFlags
                buffer.position(0)
                buffer.limit(size)
                muxer.writeSampleData(outTrack, buffer, info)
                if (!extractor.advance()) break
            }
        } finally {
            try { muxer?.stop() } catch (_: Exception) { }
            try { muxer?.release() } catch (_: Exception) { }
            try { extractor.release() } catch (_: Exception) { }
        }
        if (!out.exists() || out.length() < 1024) throw IOException("Could not extract the audio track.")
    }

    /** Lossless remux of one video-only and one audio-only stream into an MP4. */
    private fun remux(video: File, audio: File, out: File, onProgress: (Float) -> Unit) {
        out.parentFile?.mkdirs()
        out.delete()
        val vEx = MediaExtractor()
        val aEx = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            vEx.setDataSource(video.absolutePath)
            aEx.setDataSource(audio.absolutePath)

            val vTrack = firstTrackOfType(vEx, "video/")
                ?: throw IOException("The downloaded video has no video track.")
            val aTrack = firstTrackOfType(aEx, "audio/")
                ?: throw IOException("The downloaded audio has no audio track.")

            muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val vOut = muxer.addTrack(vEx.getTrackFormat(vTrack))
            val aOut = muxer.addTrack(aEx.getTrackFormat(aTrack))
            muxer.start()

            vEx.selectTrack(vTrack)
            aEx.selectTrack(aTrack)

            val vDur = trackDuration(vEx, vTrack)
            val aDur = trackDuration(aEx, aTrack)
            val totalDur = (vDur + aDur).coerceAtLeast(1L)
            val buffer = ByteBuffer.allocateDirect(2 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var base = 0L

            fun copy(from: MediaExtractor, to: Int) {
                while (true) {
                    buffer.clear()
                    val size = from.readSampleData(buffer, 0)
                    if (size < 0) break
                    info.offset = 0
                    info.size = size
                    info.presentationTimeUs = from.sampleTime
                    info.flags = from.sampleFlags
                    buffer.position(0)
                    buffer.limit(size)
                    muxer.writeSampleData(to, buffer, info)
                    val pct = ((base + from.sampleTime).toFloat() / totalDur).coerceIn(0f, 1f)
                    onProgress(pct)
                    if (!from.advance()) break
                }
                base = vDur
            }

            copy(vEx, vOut)
            copy(aEx, aOut)
            onProgress(1f)
        } finally {
            try { muxer?.stop() } catch (_: Exception) { }
            try { muxer?.release() } catch (_: Exception) { }
            try { vEx.release() } catch (_: Exception) { }
            try { aEx.release() } catch (_: Exception) { }
        }
        if (!out.exists() || out.length() < 2048) throw IOException("Merging produced an empty file.")
    }

    private fun firstTrackOfType(ex: MediaExtractor, prefix: String): Int? =
        (0 until ex.trackCount).firstOrNull {
            val mime = ex.getTrackFormat(it).getString(AndroidMediaFormat.KEY_MIME).orEmpty()
            mime.startsWith(prefix)
        }

    private fun trackDuration(ex: MediaExtractor, track: Int): Long =
        try { ex.getTrackFormat(track).getLong(AndroidMediaFormat.KEY_DURATION) } catch (e: Exception) { 0L }

    /** A finished download that is now visible in the public storage. */
    data class Published(val name: String, val uri: Uri?, val location: String)

    /**
     * Saves a finished file into the public Download folder.
     *
     * The file has to go through the **Downloads** collection to land in
     * Download/. Inserting a video into MediaStore.Video with
     * RELATIVE_PATH=Download is rejected outright by the system:
     *
     *   "Primary directory Download not allowed for
     *    content://media/external/video/media; allowed directories are
     *    [DCIM, Movies, Pictures]"
     *
     * That is exactly why the download reached 100% and then failed to save:
     * the bytes were fine, only the insert was refused. If Download is refused
     * for any reason the media collection for the file type is used instead, so
     * a finished download is never thrown away.
     *
     * No runtime permission is needed on API 29+: MediaStore hands the app its
     * own file, and the file is world-visible once IS_PENDING is cleared.
     */
    private fun publish(
        file: File,
        baseName: String,
        format: MediaFormat,
        isAudio: Boolean
    ): Published {
        val suffix = if (!isAudio && format.height > 0) " ${format.height}p" else ""
        val base = "$baseName$suffix"
        val extension = if (isAudio) "m4a" else "mp4"
        val mime = if (isAudio) "audio/mp4" else "video/mp4"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // 1. The requested place: Download/TubeGrab.
            val downloadsCol = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val downloadsPath = Environment.DIRECTORY_DOWNLOADS + "/TubeGrab"
            insertInto(downloadsCol, base, extension, mime, downloadsPath, file)
                ?.let { return Published(it.first, it.second, "Download/TubeGrab") }

            // 2. Whatever the system will actually accept for this file type.
            val fallbackCol = if (isAudio) {
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            } else {
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            }
            val fallbackPath = if (isAudio) {
                Environment.DIRECTORY_MUSIC + "/TubeGrab"
            } else {
                Environment.DIRECTORY_MOVIES + "/TubeGrab"
            }
            val label = if (isAudio) "Music/TubeGrab" else "Movies/TubeGrab"
            insertInto(fallbackCol, base, extension, mime, fallbackPath, file)
                ?.let { return Published(it.first, it.second, label) }

            throw IOException(
                "The download finished but Android refused to save it. " +
                    "Check that your storage has free space, then tap retry."
            )
        }

        // API 28 and lower: no MediaStore.Downloads, so write the file directly.
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "TubeGrab"
        )
        if (!dir.exists() && !dir.mkdirs()) {
            throw IOException("Could not create the Download/TubeGrab folder.")
        }
        val dest = uniqueFile(dir, "$base.$extension")
        file.copyTo(dest, overwrite = true)
        return Published(dest.name, Uri.fromFile(dest), "Download/TubeGrab")
    }

    /**
     * One MediaStore insert + copy, into a name that is not taken yet. Returns
     * null instead of throwing, because the caller tries more than one
     * destination.
     */
    private fun insertInto(
        collection: Uri,
        base: String,
        extension: String,
        mime: String,
        relativePath: String,
        source: File
    ): Pair<String, Uri>? {
        val resolver = context.contentResolver
        val displayName = uniqueDisplayName(collection, base, extension, relativePath)
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = try {
            resolver.insert(collection, values)
        } catch (e: Exception) {
            // IllegalArgumentException is what an unsupported directory gives.
            null
        } ?: return null

        return try {
            val out = resolver.openOutputStream(uri)
                ?: throw IOException("Could not open the output file.")
            out.use { target ->
                source.inputStream().buffered(256 * 1024).use { input ->
                    input.copyTo(target, 256 * 1024)
                }
            }
            // Clearing IS_PENDING is what makes the file visible to the media
            // scanner and to file managers.
            resolver.update(
                uri,
                ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) },
                null,
                null
            )
            displayName to uri
        } catch (e: Exception) {
            try {
                resolver.delete(uri, null, null)
            } catch (_: Exception) {
            }
            null
        }
    }

    /** "song.mp4" -> "song (1).mp4" when the name is taken. */
    private fun uniqueFile(dir: File, name: String): File {
        var candidate = File(dir, name)
        if (!candidate.exists()) return candidate
        val dot = name.lastIndexOf('.')
        val stem = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (candidate.exists() && i < 500) {
            candidate = File(dir, "$stem ($i)$ext")
            i++
        }
        return candidate
    }

    /**
     * Picks "song.mp4", "song (1).mp4", ... — whichever does not exist yet in
     * the target collection. MediaStore would otherwise append " (1)" by
     * itself, which works but leaves a name the UI cannot predict.
     */
    private fun uniqueDisplayName(
        collection: Uri,
        base: String,
        extension: String,
        relativePath: String
    ): String {
        val resolver = context.contentResolver
        var i = 0
        while (i < 500) {
            val candidate = if (i == 0) "$base.$extension" else "$base ($i).$extension"
            val projection = arrayOf(MediaStore.MediaColumns._ID)
            val selection =
                "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND " +
                    "${MediaStore.MediaColumns.RELATIVE_PATH}=?"
            val args = arrayOf(candidate, "$relativePath/")
            val exists = try {
                resolver.query(collection, projection, selection, args, null)?.use {
                    it.moveToFirst()
                } ?: false
            } catch (e: Exception) {
                // Some collections reject RELATIVE_PATH in a selection; a
                // duplicate name is then simply let through.
                false
            }
            if (!exists) return candidate
            i++
        }
        return "$base.$extension"
    }

    private fun sanitize(name: String): String {
        val cleaned = name
            .replace(Regex("[\\\\/:*?\"<>|\\n\\r\\t]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .trim('.')
        return cleaned.take(90).ifEmpty { "youtube_video" }
    }

    /** Drops partially downloaded files left over from earlier runs. */
    private fun cleanStaleCache() {
        val cutoff = System.currentTimeMillis() - 24L * 60L * 60L * 1000L
        try {
            workDir.listFiles()?.forEach { file ->
                if (file.isFile && file.lastModified() < cutoff) deleteQuietly(file)
            }
        } catch (_: Exception) {
        }
    }

    private fun deleteQuietly(file: File?) {
        try { file?.delete() } catch (_: Exception) { }
    }
}
