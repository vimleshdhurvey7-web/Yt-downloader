package com.example.ytdownloader

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** Soft ease-out: quick start, long settle. The Compose twin of CSS ease-out. */
val EaseOutSoft = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)

/**
 * The ambient backdrop: three huge, slow, very dim colour fields over the near
 * black canvas.
 *
 * This is the Compose answer to the "aurora / warp background" pattern that
 * Magic UI ships for the web. It is drawn as radial gradients in a single
 * Canvas rather than as blurred boxes, because a radial gradient already falls
 * off smoothly - no RenderEffect, no API 31 gate, and no full-screen blur that
 * would cost a frame every time the progress bar updates.
 *
 * Motion is deliberately ~38 s per cycle: it should read as "the screen is
 * alive", never as "something is moving".
 */
@Composable
fun AuroraBackdrop(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "aurora")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 38_000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "drift"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        glow(
            center = Offset(w * (0.16f + 0.10f * drift), h * (0.05f + 0.04f * drift)),
            radius = w * 0.95f,
            color = BrandRed,
            alpha = 0.16f
        )
        glow(
            center = Offset(w * (0.95f - 0.12f * drift), h * (0.34f + 0.05f * drift)),
            radius = w * 0.80f,
            color = BrandViolet,
            alpha = 0.13f
        )
        glow(
            center = Offset(w * (0.30f + 0.14f * drift), h * 0.92f),
            radius = w * 0.85f,
            color = BrandAmber,
            alpha = 0.07f
        )
    }
}

private fun DrawScope.glow(center: Offset, radius: Float, color: Color, alpha: Float) {
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                color.copy(alpha = alpha),
                color.copy(alpha = alpha * 0.35f),
                Color.Transparent
            ),
            center = center,
            radius = radius
        ),
        radius = radius,
        center = center
    )
}

/**
 * Entrance animation for a section: a short rise plus a fade, staggered by
 * [delayMillis]. Runs once when the section first appears.
 *
 * The web pattern ("blur-fade") also animates a blur; here the same intent is
 * reached with offset + alpha, because a real blur needs `Modifier.blur`, which
 * is API 31+ only and this app supports 29.
 */
@Composable
fun BlurFade(
    modifier: Modifier = Modifier,
    delayMillis: Int = 0,
    distance: Dp = 14.dp,
    content: @Composable BoxScope.() -> Unit
) {
    // rememberSaveable, not remember: these sections live in a LazyColumn, so they
    // leave composition when scrolled past. Without the saved flag the entrance
    // animation replays every time a card scrolls back into view, which reads as a
    // glitch rather than as polish.
    var played by rememberSaveable { mutableStateOf(false) }
    val progress = remember { Animatable(if (played) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!played) {
            if (delayMillis > 0) delay(delayMillis.toLong())
            progress.animateTo(1f, animationSpec = tween(460, easing = EaseOutSoft))
            played = true
        }
    }
    val p = progress.value
    Box(
        modifier = modifier
            .offset(y = distance * (1f - p))
            .alpha(p)
    ) {
        content()
    }
}

/**
 * A card that reads as a pane of tinted glass over the aurora: gradient body, a
 * 1 dp hairline, and a brighter 1 dp line along the top edge that fakes a light
 * source above the screen.
 *
 * [glow] adds a coloured wash under the top edge, used for cards that need to
 * draw the eye (the active download).
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(22.dp),
    contentPadding: Dp = 16.dp,
    tint: Color = CardSurface,
    glow: Color? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val topHighlight = Color.White.copy(alpha = 0.10f)
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(tint.copy(alpha = 0.97f), tint.copy(alpha = 0.86f))
                )
            )
            .drawBehind {
                if (glow != null) {
                    drawRect(
                        brush = Brush.verticalGradient(
                            listOf(glow.copy(alpha = 0.20f), Color.Transparent),
                            endY = size.height * 0.7f
                        )
                    )
                }
            }
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(topHighlight, Hairline.copy(alpha = 0.85f))
                ),
                shape = shape
            )
            .padding(contentPadding)
    ) {
        content()
    }
}

/**
 * A hairline that is brightest in the middle and fades at both ends. Used under
 * the app bar so it dissolves into the background instead of stop-starting.
 */
@Composable
fun FadingRule(modifier: Modifier = Modifier, color: Color = Hairline) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(1.dp)
            .drawBehind {
                drawRect(
                    brush = Brush.horizontalGradient(
                        listOf(Color.Transparent, color, Color.Transparent)
                    )
                )
            }
    )
}
