package com.example.ytdownloader

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------------------
// Palette
//
// The app is dark-first: a downloader is used at night, next to a video, and a
// deep neutral canvas lets the artwork and the red accent carry the screen. The
// neutrals are deliberately warm-shifted (a trace of red in every grey) so the
// crimson accent does not look pasted on top of a cold grey UI.
// ---------------------------------------------------------------------------

/** The one saturated accent. Used for the brand mark, the primary action and selection. */
val BrandRed = Color(0xFFFF3B4E)
val BrandRedDeep = Color(0xFFC4112B)
/** Warm highlight used for gradient ends so the accent never looks flat. */
val BrandAmber = Color(0xFFFF8A4C)
/** Cool counterpoint for the ambient backdrop. */
val BrandViolet = Color(0xFF7B5CFF)

val Canvas = Color(0xFF0B0A0C)
val CanvasRaised = Color(0xFF141216)
val CardSurface = Color(0xFF1A171C)
val CardSurfaceHigh = Color(0xFF221E24)
val Hairline = Color(0xFF2E2830)

val InkPrimary = Color(0xFFF5F1F4)
val InkSecondary = Color(0xFFA79EA9)
val InkTertiary = Color(0xFF6F6673)

val SuccessGreen = Color(0xFF3DDC97)
val WarnAmber = Color(0xFFFFB020)
val ErrorRed = Color(0xFFFF5A6E)

private val TubeGrabColors = darkColorScheme(
    primary = BrandRed,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF3A0A14),
    onPrimaryContainer = Color(0xFFFFD9DE),
    secondary = BrandAmber,
    onSecondary = Color(0xFF2A1200),
    secondaryContainer = Color(0xFF33200F),
    onSecondaryContainer = Color(0xFFFFDCBF),
    tertiary = BrandViolet,
    onTertiary = Color.White,
    background = Canvas,
    onBackground = InkPrimary,
    surface = CanvasRaised,
    onSurface = InkPrimary,
    surfaceVariant = CardSurface,
    onSurfaceVariant = InkSecondary,
    surfaceContainerHigh = CardSurfaceHigh,
    outline = Color(0xFF443C47),
    outlineVariant = Hairline,
    error = ErrorRed,
    onError = Color.White,
    errorContainer = Color(0xFF3A0D16),
    onErrorContainer = Color(0xFFFFD9DE)
)

// ---------------------------------------------------------------------------
// Typography
//
// Both bundled faces are variable fonts, so every weight is synthesised from a
// single file instead of shipping five static weights each. Space Grotesk
// carries the display/title voice (its wide, slightly quirky letterforms read as
// "product" rather than "system"), Inter carries all running text because it
// stays legible at 11-13 sp on a phone.
// ---------------------------------------------------------------------------

// FontVariation.Settings is still marked experimental in Compose 1.7, but it is
// the only way to pick a weight out of a variable font at runtime. Without it we
// would have to ship a separate file per weight (~900 KB each for Inter).
@OptIn(ExperimentalTextApi::class)
private fun variableFont(resId: Int, weight: Int): Font =
    Font(
        resId = resId,
        weight = FontWeight(weight),
        variationSettings = FontVariation.Settings(FontVariation.weight(weight))
    )

val SpaceGrotesk = FontFamily(
    variableFont(R.font.space_grotesk, 500),
    variableFont(R.font.space_grotesk, 600),
    variableFont(R.font.space_grotesk, 700)
)

val Inter = FontFamily(
    variableFont(R.font.inter, 400),
    variableFont(R.font.inter, 500),
    variableFont(R.font.inter, 600),
    variableFont(R.font.inter, 700)
)

private val TubeGrabTypography = Typography(
    displaySmall = TextStyle(
        fontFamily = SpaceGrotesk,
        fontWeight = FontWeight.SemiBold,
        fontSize = 30.sp,
        lineHeight = 36.sp,
        letterSpacing = (-0.6).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = SpaceGrotesk,
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        lineHeight = 30.sp,
        letterSpacing = (-0.4).sp
    ),
    titleLarge = TextStyle(
        fontFamily = SpaceGrotesk,
        fontWeight = FontWeight.SemiBold,
        fontSize = 21.sp,
        lineHeight = 26.sp,
        letterSpacing = (-0.3).sp
    ),
    titleMedium = TextStyle(
        fontFamily = SpaceGrotesk,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        letterSpacing = (-0.1).sp
    ),
    titleSmall = TextStyle(
        fontFamily = SpaceGrotesk,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 19.sp,
        letterSpacing = 0.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = Inter,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 21.sp,
        letterSpacing = 0.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = Inter,
        fontWeight = FontWeight.Normal,
        fontSize = 13.5.sp,
        lineHeight = 19.sp
    ),
    bodySmall = TextStyle(
        fontFamily = Inter,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 17.sp
    ),
    labelLarge = TextStyle(
        fontFamily = Inter,
        fontWeight = FontWeight.Medium,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.1.sp
    ),
    labelMedium = TextStyle(
        fontFamily = Inter,
        fontWeight = FontWeight.Medium,
        fontSize = 11.5.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.3.sp
    ),
    labelSmall = TextStyle(
        fontFamily = Inter,
        fontWeight = FontWeight.Medium,
        fontSize = 10.5.sp,
        lineHeight = 14.sp,
        letterSpacing = 0.5.sp
    )
)

@Composable
fun TubeGrabTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TubeGrabColors,
        typography = TubeGrabTypography,
        content = content
    )
}
