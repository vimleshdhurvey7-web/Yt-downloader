package com.example.ytdownloader

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Installed first so a crash in setContent is still recorded.
        CrashLog.install(this)
        // The UI is dark-only, so the bars must be dark regardless of the system
        // theme. The default enableEdgeToEdge() follows the system: on a phone set
        // to light mode it installs dark status icons, which are invisible on our
        // near-black canvas.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        handleIncoming(intent)
        // A crash from the previous run is shown as a normal error card, which
        // is the only way the user can report it without logcat.
        viewModel.reportPreviousCrash(CrashLog.lastSummary(this), CrashLog.lastTime(this))
        setContent {
            TubeGrabTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppScreen(viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    override fun onDestroy() {
        // Reaching a clean destroy means the last crash was already reported.
        if (!isChangingConfigurations) CrashLog.clear(this)
        super.onDestroy()
    }

    /** Accepts "Share to TubeGrab" text from the YouTube app. */
    private fun handleIncoming(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val shared = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
        val id = InnerTube.extractVideoId(shared) ?: return
        viewModel.pasteAndFetch("https://www.youtube.com/watch?v=$id")
    }
}
