package com.example.ytdownloader

import android.net.Uri

/** A single downloadable stream (video-only, audio-only or progressive). */
data class MediaFormat(
    val itag: Int,
    val url: String,
    val mimeType: String,
    val codec: String,
    val extension: String,
    val isAudio: Boolean,
    val isProgressive: Boolean,
    val width: Int,
    val height: Int,
    val fps: Int,
    val bitrate: Long,
    val sizeBytes: Long,
    val label: String,
    val badge: String,
    val userAgent: String,
    /** "English original", "Hindi"… only set for audio; null when YouTube sends one track. */
    val audioTrackName: String? = null,
    /** True for the video's original audio, false for an auto-dubbed translation. */
    val originalAudio: Boolean = true
)

data class VideoInfo(
    val videoId: String,
    val title: String,
    val author: String,
    val durationSeconds: Long,
    val viewCount: Long,
    val thumbnailUrl: String,
    val videoFormats: List<MediaFormat>,
    val audioFormats: List<MediaFormat>,
    val progressiveFormats: List<MediaFormat>
) {
    val durationLabel: String
        get() {
            val h = durationSeconds / 3600
            val m = (durationSeconds % 3600) / 60
            val s = durationSeconds % 60
            return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, s)
            else String.format(java.util.Locale.US, "%d:%02d", m, s)
        }

    val viewsLabel: String
        get() {
            val v = viewCount
            return when {
                v <= 0 -> ""
                v >= 1_000_000_000 -> String.format(java.util.Locale.US, "%.1fB views", v / 1_000_000_000.0)
                v >= 1_000_000 -> String.format(java.util.Locale.US, "%.1fM views", v / 1_000_000.0)
                v >= 1_000 -> String.format(java.util.Locale.US, "%.1fK views", v / 1_000.0)
                else -> "$v views"
            }
        }
}

/** Result of a video info fetch. */
sealed interface FetchResult {
    data class Success(val info: VideoInfo) : FetchResult
    data class Failure(val message: String) : FetchResult
}

/** Progress state of the active download. */
sealed interface DownloadState {
    data object Idle : DownloadState
    data class Running(
        val stage: String,
        val percent: Float,
        val downloadedBytes: Long,
        val totalBytes: Long,
        val speedBytesPerSec: Long
    ) : DownloadState

    /**
     * [audioFromProgressive] is true when YouTube refused the audio-only stream
     * and the audio had to be taken out of the combined (360p) stream instead.
     */
    data class Done(
        val fileName: String,
        val location: String,
        val uri: Uri?,
        val audioFromProgressive: Boolean = false
    ) : DownloadState
    data class Failed(val message: String) : DownloadState
}
