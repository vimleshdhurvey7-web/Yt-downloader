package com.example.ytdownloader

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream

/**
 * Minimal YouTube InnerTube client.
 *
 * Several official player clients are tried in turn (ANDROID, IOS, ANDROID_VR,
 * VISIONOS) because YouTube alternates which of them it trusts. All of them
 * hand out direct (non-ciphered) googlevideo URLs, so no JavaScript signature
 * solving is needed on device.
 */
object InnerTube {

    /** Non-2xx answer from the InnerTube endpoint, carrying the HTTP status. */
    private class HttpFailure(val code: Int) : IOException("Server returned HTTP $code.") {
        fun describe(): String = when (code) {
            in 500..599 -> "YouTube is having trouble right now (HTTP $code). Try again in a minute."
            429 -> "YouTube is rate limiting this connection. Wait a minute and try again."
            else -> "YouTube rejected the request (HTTP $code)."
        }
    }

    private const val PLAYER_URL =
        "https://www.youtube.com/youtubei/v1/player?key=AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8"

    private class Client(
        val name: String,
        val version: String,
        val ua: String,
        val sdk: Int,
        val osName: String,
        val osVersion: String,
        val deviceMake: String? = null,
        val deviceModel: String? = null,
        val embed: Boolean = false,
        /**
         * Some clients (VISIONOS) only hand out streams when they also get a
         * visitor id. Without it YouTube answers LOGIN_REQUIRED.
         */
        val needsVisitorData: Boolean = false
    )

    /**
     * Cached anonymous visitor id. It is fetched once per process and reused,
     * because asking for a new one on every player call is itself suspicious.
     */
    @Volatile
    private var visitorData: String? = null

    private fun visitorId(client: Client): String? {
        if (!client.needsVisitorData) return null
        visitorData?.let { return it }
        return try {
            val body = JSONObject().apply {
                put(
                    "context", JSONObject().apply {
                        put(
                            "client", JSONObject().apply {
                                put("clientName", "ANDROID")
                                put("clientVersion", "20.10.38")
                                put("androidSdkVersion", 35)
                                put("osName", "Android")
                                put("osVersion", "15")
                                put("hl", "en")
                                put("gl", "US")
                            }
                        )
                    }
                )
            }.toString()
            val text = post(
                "https://www.youtube.com/youtubei/v1/visitor_id?key=AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8",
                body,
                "com.google.android.youtube/20.10.38 (Linux; U; Android 15) gzip"
            )
            val root = JSONObject(text)
            val id = root.optJSONObject("responseContext")?.optString("visitorData")
                ?.takeIf { it.isNotEmpty() }
                ?: root.optString("visitorData").takeIf { it.isNotEmpty() }
            if (id != null) visitorData = id
            id
        } catch (e: Exception) {
            null
        }
    }
    /**
     * Client fallback order. Which InnerTube client YouTube trusts changes every
     * few months, so several are tried in turn. All of these return plain
     * (non-ciphered) stream URLs, so no signature solving is needed on device.
     *
     * Outdated client versions are rejected with `HTTP 400 Precondition check
     * failed`, and older clients now trigger the "confirm you're not a bot"
     * screen, so this list is the first thing to update when fetching breaks.
     * ANDROID also exposes progressive (video + audio in one file) streams,
     * which is what the "single file" switch uses.
     *
     * VISIONOS goes first on purpose. Measured against this network, every
     * ANDROID/IOS URL stops answering after 1.56 MB ("bytes=0-1.56MB" is the
     * largest range that still returns 206, and any offset at or past 2 MB is
     * a flat 403), so an adaptive 1080p track could never finish. A VISIONOS
     * URL fetched with a visitor id serves the whole file: 80.9 MB at 1080p and
     * 33.5 MB at 720p both completed byte-for-byte. VISIONOS does not expose
     * progressive (combined) streams, so ANDROID stays in the list for those.
     */
    private val clients = listOf(
        Client(
            name = "VISIONOS",
            version = "1.02",
            ua = "com.google.ios.youtube/1.02 (iPhone16,2; U; CPU iOS 18_1_0 like Mac OS X;)",
            sdk = 0,
            osName = "visionOS",
            osVersion = "1.3.0.21O771",
            deviceMake = "Apple",
            deviceModel = "RealityDevice14,1",
            needsVisitorData = true
        ),
        Client(
            name = "ANDROID",
            version = "20.10.38",
            ua = "com.google.android.youtube/20.10.38 (Linux; U; Android 15) gzip",
            sdk = 35,
            osName = "Android",
            osVersion = "15"
        ),
        Client(
            name = "ANDROID",
            version = "20.22.35",
            ua = "com.google.android.youtube/20.22.35 (Linux; U; Android 15) gzip",
            sdk = 35,
            osName = "Android",
            osVersion = "15"
        ),
        Client(
            name = "IOS",
            version = "20.10.4",
            ua = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_1_0 like Mac OS X;)",
            sdk = 0,
            osName = "iPhone",
            osVersion = "18.1.0.22B83",
            deviceMake = "Apple",
            deviceModel = "iPhone16,2"
        ),
        Client(
            name = "ANDROID_VR",
            version = "1.61.48",
            ua = "com.google.android.apps.youtube.vr.oculus/1.61.48 (Linux; U; Android 12; GB) gzip",
            sdk = 32,
            osName = "Android",
            osVersion = "12",
            deviceMake = "Oculus",
            deviceModel = "Quest 3"
        )
    )

    /**
     * A downloadable URL plus the User-Agent of the client that minted it.
     * googlevideo ties a signature to the request that produced it, so the two
     * must travel together.
     */
    data class StreamSource(val url: String, val userAgent: String, val clientName: String)

    /**
     * Re-asks the player endpoint for a brand new URL for one itag.
     *
     * This has to be re-done regularly: googlevideo URLs embed the requesting
     * IP address (`sparams` includes `ip`) and expire after a few hours, so a
     * URL saved at info time stops working the moment the phone hops between
     * Wi-Fi and mobile data or its IPv6 prefix rotates - every further request
     * then answers `HTTP 403` with an empty body.
     *
     * The first client that offers the itag wins; a different client than the
     * original is fine, because the matching User-Agent is returned with it.
     */
    fun resolveStream(videoId: String, itag: Int, preferClient: String? = null): StreamSource? =
        resolveStreams(videoId, itag, preferClient).firstOrNull()

    /**
     * Every client that can serve [itag], best first.
     *
     * googlevideo gates streams per client *and* per network: on one connection
     * VISIONOS serves a whole 1080p track, on another it serves 1.5 MB and then
     * answers 403 forever. Re-minting a URL from the same client is then
     * useless, so the caller needs the alternatives ready and must be able to
     * switch to a different client when one goes dead. [preferClient] is tried
     * first so a healthy client is not abandoned mid-download.
     */
    fun resolveStreams(videoId: String, itag: Int, preferClient: String? = null): List<StreamSource> {
        val ordered = if (preferClient == null) clients
        else clients.sortedBy { if (it.name == preferClient) 0 else 1 }

        val out = LinkedHashMap<String, StreamSource>()
        for (client in ordered) {
            val source = try {
                findStream(postPlayer(videoId, client), itag, client)
            } catch (e: Exception) {
                null
            } ?: continue
            // One URL per client is enough; duplicates waste a player call.
            out.putIfAbsent(client.name, source)
        }
        return out.values.toList()
    }

    private fun findStream(body: String, itag: Int, client: Client): StreamSource? {
        val streaming = JSONObject(body).optJSONObject("streamingData") ?: return null
        for (key in arrayOf("adaptiveFormats", "formats")) {
            val arr = streaming.optJSONArray(key) ?: continue
            for (i in 0 until arr.length()) {
                val f = arr.optJSONObject(i) ?: continue
                if (f.optInt("itag") != itag) continue
                val url = f.optString("url")
                if (url.isNotEmpty()) return StreamSource(url, client.ua, client.name)
            }
        }
        return null
    }

    /** Extracts an 11 character video id from almost any YouTube link or raw id. */
    fun extractVideoId(input: String): String? {
        val text = input.trim()
        if (text.isEmpty()) return null

        // A bare id, optionally followed by tracking params: "dQw4w9WgXcQ?si=..."
        Regex("^([A-Za-z0-9_-]{11})(?:[?&#/].*)?$").find(text)?.let {
            return it.groupValues[1]
        }

        val patterns = listOf(
            Regex("[?&#]v=([A-Za-z0-9_-]{11})"),
            Regex("youtu\\.be/([A-Za-z0-9_-]{11})"),
            Regex("/shorts/([A-Za-z0-9_-]{11})"),
            Regex("/embed/([A-Za-z0-9_-]{11})"),
            Regex("/live/([A-Za-z0-9_-]{11})"),
            Regex("/v/([A-Za-z0-9_-]{11})"),
            Regex("/watch/([A-Za-z0-9_-]{11})")
        )
        for (p in patterns) {
            val m = p.find(text)
            if (m != null) return m.groupValues[1]
        }
        return null
    }

    suspend fun fetchVideoInfo(videoId: String): FetchResult = withContext(Dispatchers.IO) {
        // A failure from the player itself ("sign in to confirm", age gate,
        // private video...) is far more useful than a transport error, so it
        // wins over whatever the last client happened to throw.
        var reason: String? = null
        var transport: String? = null

        for (client in clients) {
            try {
                when (val result = tryClient(videoId, client)) {
                    is FetchResult.Success -> return@withContext result
                    is FetchResult.Failure -> if (reason == null) reason = result.message
                }
            } catch (e: HttpFailure) {
                // A 400 means this client version is no longer accepted by
                // YouTube; keep trying the others instead of showing "HTTP 400".
                if (e.code !in 400..499) {
                    if (reason == null && transport == null) transport = e.describe()
                }
            } catch (e: IOException) {
                if (transport == null) transport = e.message ?: "Network error"
            } catch (e: Exception) {
                if (transport == null) transport = e.message ?: "Network error"
            }
        }

        FetchResult.Failure(
            reason ?: transport
            ?: "Could not reach YouTube's player. Check your internet connection and try again."
        )
    }

    /** Builds the request body and POSTs it, returning the raw JSON answer. */
    private fun postPlayer(videoId: String, client: Client): String {
        // VISIONOS refuses to play without a visitor id: without it the answer
        // is LOGIN_REQUIRED "Sign in to confirm you're not a bot".
        val visitor = visitorId(client)
        val payload = JSONObject().apply {
            put(
                "context", JSONObject().apply {
                    put(
                        "client", JSONObject().apply {
                            put("clientName", client.name)
                            put("clientVersion", client.version)
                            put("osName", client.osName)
                            put("osVersion", client.osVersion)
                            put("hl", "en")
                            put("gl", "US")
                            put("userAgent", client.ua)
                            if (client.sdk > 0) put("androidSdkVersion", client.sdk)
                            client.deviceMake?.let { put("deviceMake", it) }
                            client.deviceModel?.let { put("deviceModel", it) }
                            if (!visitor.isNullOrEmpty()) put("visitorData", visitor)
                        }
                    )
                    if (client.embed) {
                        put("thirdParty", JSONObject().apply {
                            put("embedUrl", "https://www.youtube.com/")
                        })
                    }
                }
            )
            put("videoId", videoId)
            put("contentCheckOk", true)
            put("racyCheckOk", true)
        }
        return post(PLAYER_URL, payload.toString(), client.ua, visitor)
    }

    private fun tryClient(videoId: String, client: Client): FetchResult {
        val root = JSONObject(postPlayer(videoId, client))

        val playability = root.optJSONObject("playabilityStatus")
        val status = playability?.optString("status").orEmpty()
        if (status != "OK") {
            val reason = playability?.optString("reason").orEmpty()
            return FetchResult.Failure(humanReadable(status, reason))
        }

        val details = root.optJSONObject("videoDetails")
            ?: return FetchResult.Failure("No video details were returned.")
        val streaming = root.optJSONObject("streamingData")
            ?: return FetchResult.Failure("No streams are available for this video.")

        val adaptive = streaming.optJSONArray("adaptiveFormats") ?: JSONArray()
        val progressive = streaming.optJSONArray("formats") ?: JSONArray()

        val videoFormats = ArrayList<MediaFormat>()
        val audioFormats = ArrayList<MediaFormat>()
        val progressiveFormats = ArrayList<MediaFormat>()

        for (i in 0 until adaptive.length()) {
            val f = adaptive.optJSONObject(i) ?: continue
            val parsed = parseFormat(f, isProgressive = false, ua = client.ua) ?: continue
            if (parsed.isAudio) audioFormats.add(parsed) else videoFormats.add(parsed)
        }
        for (i in 0 until progressive.length()) {
            val f = progressive.optJSONObject(i) ?: continue
            val parsed = parseFormat(f, isProgressive = true, ua = client.ua) ?: continue
            progressiveFormats.add(parsed)
        }

        // Some clients (VISIONOS) serve adaptive streams without the byte gate
        // but expose no combined "video + audio" file at all. When that happens
        // the progressive list is topped up from ANDROID, which does have itag
        // 18. Mixing is safe because each MediaFormat carries the User-Agent of
        // the client that minted its URL, and download() uses that UA.
        if (progressiveFormats.isEmpty()) {
            progressiveFormats.addAll(progressiveFromAndroid(videoId))
        }

        // One entry per resolution (prefer MP4/H.264, which merges fastest) and
        // one per itag for audio (prefer the original track, then m4a/AAC).
        //
        // Audio must be keyed by itag and not by bitrate: YouTube splits one
        // track across a kbps boundary (132719 and 133179 sit either side of
        // 132), so a bitrate bucket yields the same itag twice. Those duplicate
        // entries then become duplicate LazyColumn keys, and Compose throws
        // "Key was already used" as soon as the list is composed - which is the
        // crash this replaced.
        val bestVideo = videoFormats
            .groupBy { it.height }
            .map { (_, list) -> list.minBy { videoPreference(it) } }
            .sortedByDescending { it.height }

        val preferredAudio = audioFormats
            .filter { it.originalAudio }
            .ifEmpty { audioFormats }
            .filter { it.extension == "m4a" }
            .ifEmpty { audioFormats.filter { it.originalAudio }.ifEmpty { audioFormats } }

        val bestAudio = preferredAudio
            .groupBy { it.itag }
            .map { (_, list) -> list.minBy { audioPreference(it) } }
            .sortedByDescending { it.bitrate }

        val thumb = details.optJSONObject("thumbnail")
            ?.optJSONArray("thumbnails")
            ?.let { arr -> if (arr.length() > 0) arr.optJSONObject(arr.length() - 1)?.optString("url").orEmpty() else "" }
            .orEmpty()

        val info = VideoInfo(
            videoId = videoId,
            title = details.optString("title", "Untitled video"),
            author = details.optString("author", ""),
            durationSeconds = details.optString("lengthSeconds", "0").toLongOrNull() ?: 0L,
            viewCount = details.optString("viewCount", "0").toLongOrNull() ?: 0L,
            thumbnailUrl = thumb,
            videoFormats = bestVideo,
            audioFormats = bestAudio,
            progressiveFormats = progressiveFormats
                .filter { it.extension == "mp4" }
                .distinctBy { it.itag }
                .sortedByDescending { it.height }
        )
        if (info.videoFormats.isEmpty() && info.progressiveFormats.isEmpty()) {
            return FetchResult.Failure("No downloadable video streams were found.")
        }
        return FetchResult.Success(info)
    }

    /**
     * Combined video+audio streams, asked from ANDROID specifically.
     *
     * Only ANDROID exposes `formats[]` (itag 18, 360p, H.264 + AAC), which is
     * what the "single file" switch and the audio fallback both rely on.
     * Failure is not fatal: the list simply stays empty.
     */
    private fun progressiveFromAndroid(videoId: String): List<MediaFormat> {
        val android = clients.firstOrNull { it.name == "ANDROID" } ?: return emptyList()
        val root = try {
            JSONObject(postPlayer(videoId, android))
        } catch (e: Exception) {
            return emptyList()
        }
        if (root.optJSONObject("playabilityStatus")?.optString("status") != "OK") return emptyList()
        val progressive = root.optJSONObject("streamingData")?.optJSONArray("formats")
            ?: return emptyList()
        val result = ArrayList<MediaFormat>()
        for (i in 0 until progressive.length()) {
            val f = progressive.optJSONObject(i) ?: continue
            parseFormat(f, isProgressive = true, ua = android.ua)?.let { result.add(it) }
        }
        return result
    }

    private fun humanReadable(status: String, reason: String): String = when {
        status == "LOGIN_REQUIRED" || reason.contains("not a bot", true) ||
            reason.contains("sign in", true) ->
            "YouTube blocked this request from your network:\n" +
                "\"Sign in to confirm you're not a bot\".\n\n" +
                "This is a network/IP check, not an app bug. It clears up on its " +
                "own after a while; switching to mobile data or another Wi-Fi " +
                "usually works immediately. Video info and downloads both use " +
                "this connection, so retry once you are on a different network."
        status == "AGE_CHECK_REQUIRED" || reason.contains("age", true) ->
            "This video is age restricted and cannot be downloaded."
        status == "LIVE_STREAM_OFFLINE" -> "This live stream has not started yet."
        status == "UNPLAYABLE" && reason.contains("reload", true) ->
            "YouTube asked for a page reload, which usually means this network " +
                "is being flagged. Try again in a minute or on another network."
        reason.isNotEmpty() -> reason
        else -> "This video is not available (status: $status)."
    }

    private fun videoPreference(f: MediaFormat): Int {
        var score = 100
        if (f.extension == "mp4") score -= 40
        when {
            f.codec.startsWith("avc1") -> score -= 20
            f.codec.startsWith("av01") -> score -= 10
        }
        return score
    }

    private fun audioPreference(f: MediaFormat): Int {
        var score = 100
        if (f.extension == "m4a") score -= 50
        if (f.codec.contains("mp4a")) score -= 20
        return score
    }

    private fun parseFormat(f: JSONObject, isProgressive: Boolean, ua: String): MediaFormat? {
        val mime = f.optString("mimeType")
        if (mime.isEmpty()) return null
        val url = f.optString("url")
        if (url.isEmpty()) return null // ciphered stream, skip
        val codecs = Regex("codecs=\"([^\"]+)\"").find(mime)?.groupValues?.get(1).orEmpty()
        val container = mime.substringBefore(";")
        val isAudio = container.startsWith("audio/")
        val ext = when {
            container.contains("mp4") -> if (isAudio) "m4a" else "mp4"
            container.contains("webm") -> "webm"
            container.contains("3gpp") -> "3gp"
            else -> "bin"
        }
        val bitrate = f.optLong("bitrate")
        // contentLength is a string when present and missing on some clients
        // (e.g. ANDROID progressive streams), so fall back to bitrate x time.
        val declaredSize = f.optString("contentLength").toLongOrNull()
            ?: f.optLong("contentLength").takeIf { it > 0 }
        val approxMs = f.optString("approxDurationMs").toLongOrNull() ?: 0L
        val size = when {
            declaredSize != null && declaredSize > 0 -> declaredSize
            bitrate > 0 && approxMs > 0 -> approxMs * bitrate / 8000
            else -> 0L
        }
        val height = f.optInt("height")
        val label = if (isAudio) {
            val kbps = if (bitrate > 0) bitrate / 1000 else 0
            when {
                kbps >= 250 -> "High quality ($kbps kbps)"
                kbps >= 120 -> "Medium quality ($kbps kbps)"
                kbps > 0 -> "Low quality ($kbps kbps)"
                else -> "Audio"
            }
        } else {
            f.optString("qualityLabel").ifEmpty { if (height > 0) "${height}p" else "Video" }
        }
        val badge = when {
            ext == "m4a" -> "M4A"
            codecs.startsWith("avc1") -> "MP4 · H.264"
            codecs.startsWith("av01") -> "MP4 · AV1"
            codecs.startsWith("vp9") || codecs.startsWith("vp09") -> "WEBM · VP9"
            ext == "mp4" -> "MP4"
            else -> ext.uppercase()
        }
        // Auto-dubbed videos carry one audio entry per language, and several of
        // them can share an itag. Only the original track is offered: the dubbed
        // ones are machine voice-overs, and duplicate itags would also collide
        // with the LazyColumn keys in the format list.
        val audioTrack = f.optJSONObject("audioTrack")
        val trackName = if (isAudio) audioTrack?.optString("displayName")?.takeIf { it.isNotEmpty() } else null
        val isOriginal = if (isAudio) {
            audioTrack?.let { it.optBoolean("audioIsDefault", true) } ?: true
        } else true
        return MediaFormat(
            itag = f.optInt("itag"),
            url = url,
            mimeType = container,
            codec = codecs,
            extension = ext,
            isAudio = isAudio,
            isProgressive = isProgressive || (!isAudio && f.has("audioQuality")),
            width = f.optInt("width"),
            height = height,
            fps = f.optInt("fps"),
            bitrate = bitrate,
            sizeBytes = size,
            label = label,
            badge = badge,
            userAgent = ua,
            audioTrackName = trackName,
            originalAudio = isOriginal
        )
    }

    private fun post(
        url: String,
        body: String,
        userAgent: String,
        visitor: String? = null
    ): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 30_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            setRequestProperty("User-Agent", userAgent)
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-Goog-Api-Format-Version", "2")
            if (!visitor.isNullOrEmpty()) setRequestProperty("X-Goog-Visitor-Id", visitor)
        }
        try {
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else (conn.errorStream ?: conn.inputStream)
            val text = readText(stream, conn.contentEncoding)
            if (code !in 200..299) throw HttpFailure(code)
            return text
        } finally {
            conn.disconnect()
        }
    }

    private fun readText(stream: java.io.InputStream, encoding: String?): String {
        val input = if (encoding?.contains("gzip", true) == true) GZIPInputStream(stream) else stream
        val out = ByteArrayOutputStream()
        input.use { s ->
            val buf = ByteArray(16 * 1024)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
            }
        }
        return out.toString("UTF-8")
    }
}
